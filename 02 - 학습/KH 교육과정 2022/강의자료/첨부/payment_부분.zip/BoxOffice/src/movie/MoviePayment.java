package movie;

import java.util.Scanner;

public class MoviePayment {
	public static void main(String[] args) {
		MoviePayment test = new MoviePayment(); 
//		test.movieList1();
//		test.sneckList1();
//		test.pay1();
		test.kiosk();
	}	
	private	Scanner sc = new Scanner(System.in);
	int Anum = 0; 
	int Tnum = 0; 
	int Pnum = 0;
	int Snum = 0;
	int Snum1 = 0;
	int Snum2 = 0;
	int Dnum = 0;
	int Tsnum = 0;
	int price = 0;	
	int customermoney = 0;
	

	public void kiosk() {
		
			String menu = "-------- @@ 영화관 티켓 발권 서비스------- \n"
						+ "1. 영화 예매 바로가기 \n"
						+ "2. 매점 바로가기 \n"
						+ "0. 종료 \n"
						+ "------------------------------------ \n"
						+ "원하시는 메뉴를 왼쪽 번호로 선택해주세요.\n"
						+ "------------------------------------ \n";
			
			do {
				System.out.print(menu);
				String choice = sc.next();
				
				switch(choice) {
				case "1" : movieList1(); break;
				case "2" : sneckList1(); break;
				case "0" : System.out.println("이용해주셔서 감사합니다."); return;
				default: System.out.println("잘못 입력하셨습니다."); 
				}
			} while(true);
		}
	



	public void pay1() {
		
		Scanner sc = new Scanner (System.in);
		String pay = "결제 방식을 선택하세요 \n 1. 카드 2. 현금";
				
			while(true) {
				System.out.println(pay);
				int choice = sc.nextInt();
		
					switch(choice) {
					case 1 : 
						price = (Anum * 13_000 + Tnum * 8_000) + (Snum * 3500 + Snum1 * 5000 + Snum2 * 4500 + Dnum * 3500);
						System.out.println("카드를 선택하셨습니다.\n결제 금액은 " + price + "원 입니다. \n");
						System.out.println("--------------------------------- \n결제 완료 되었습니다.\n즐거운 관람되세요");
						break;
						
					case 2 : 
                        price = (Anum * 13_000 + Tnum * 8_000) + (Snum * 3500 + Snum1 * 5000 + Snum2 * 4500 + Dnum * 3500);
                        System.out.println("현금를 선택하셨습니다.\n결제 금액은 " + price + "원 입니다. \n");
                        System.out.println("현금을 넣어주세요 \n");
                        
                        while(true) {                                
                            customermoney = sc.nextInt();
                            if (customermoney < price) {
                            System.out.println("현금이 부족합니다.\n 다시 결제 해 주세요");
                            continue;
                            }
                            else if(customermoney > price || customermoney == price ) {
                                customermoney -= price;
                                System.out.println("결제 완료 되었습니다. \n잔액은 "  + customermoney + "입니다."
                                        + " 즐거운 관람 되세요. 감사합니다. \n"); 
                                break;
                                
                    }break;
			} 
					case 0 : kiosk(); break;
					default : System.out.println("잘못 된 번호입니다.");
		} break;
	}
}	

	public void sneckList1() {
		Scanner sc = new Scanner (System.in);
		String sneck = 
					"------------- 매점 메뉴------------\n"
					 + "10. 오리지널 팝콘 - 3500 \n"
					 + "11. 캬라멜 팝콘 - 3500 \n"
					 + "12. 어니언 팝콘 - 3500 \n"
					 + "13. 버터오징어 - 5000 \n"
					 + "14. 나초  - 4500 \n"
					 + ">------------ 음료 -----------< \n"
					 + "20. 코카콜라 m - 3500 	\n"
					 + "21. 스프라이트 m - 3500 \n"
					 + "22. 오렌지주스 m - 3500 \n"
					 + "0. 종료 \n"
					 + "--------------------------------- \n"
					 + "원하시는 메뉴를 왼쪽 번호로 선택해주세요. \n"
					 + "---------------------------------";
		
		while(true) {
			System.out.println(sneck);
			int choice = sc.nextInt();
			
			switch(choice) {
			case 10 : 
				System.out.println("오리지널 팝콘을 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Snum = sc.nextInt();
	
				Tsnum = Snum + Dnum + Snum1 + Snum2;
				System.out.printf("오리지널 팝콘 %d 개를 선택 하셨습니다. \n\n", Snum); 
				break;
			case 11 : 
				System.out.println("캬라멜 팝콘을 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Snum = sc.nextInt();

				Tsnum = Snum + Dnum + Snum1 + Snum2;
				System.out.printf("캬라멜 팝콘 %d 개를 선택 하셨습니다. \n\n", Snum); 
				break;
			case 12 : 
				System.out.println("어니언 팝콘을 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Snum = sc.nextInt();

				Tsnum = Snum + Dnum + Snum1 + Snum2;
				System.out.printf("어니언 팝콘 %d 개를 선택 하셨습니다. \n\n", Snum); 
				break;
			case 13 : 
				System.out.println("버터 오징어를 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Snum1 = sc.nextInt();

				Tsnum = Snum + Dnum + Snum1 + Snum2;
				System.out.printf("버터 오징어 %d 개를 선택 하셨습니다. \n\n", Snum1); 
				break;
			case 14 : 
				System.out.println("나초를 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Snum2 = sc.nextInt();

				Tsnum = Snum + Dnum + Snum1 + Snum2;
				System.out.printf("나초 %d 개를 선택 하셨습니다. \n\n", Snum2); 
				break;
			case 20 :
				System.out.println("코카콜라를 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Dnum = sc.nextInt();

				Tsnum = Snum + Dnum + Snum1 + Snum2;
				System.out.printf("코카콜라 %d 개를 선택 하셨습니다. \n\n", Dnum); 
				break;
			case 21 : 
				System.out.println("스프라이트를 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Dnum = sc.nextInt();

				Tsnum = Snum + Dnum + Snum1 + Snum2;
				System.out.printf("스프라이트 %d 개를 선택 하셨습니다. \n\n", Dnum); 
				break;
			case 22 : 
				System.out.println("오렌지 주스를 선택하셨습니다.");
				System.out.println("구매 수량을 입력해 주세요.");
				Dnum = sc.nextInt();

				System.out.printf("오렌지 주스 %d 개를 선택 하셨습니다. \n\n", Dnum); 
				break;
			case 0 : pay1(); break;
			default : System.out.println("잘못 된 번호입니다.");
				
			}
		}
		
		
	}
	public void movieList1() {
		Scanner sc = new Scanner (System.in);	
		String moviemenu = 
					"------------- 상영 영화 ------------\n"
					 + "1. 더 배트맨 \n"
					 + "2. 이상한 나라의 수학자 \n"
					 + "3. 언차티드 \n"
					 + "4. 블랙라이트 \n"
					 + "5. 스파이더맨: 노 웨이 홈 \n"
					 + "--------------------------------- \n"
					 + "6. 매점으로 이동 \n"
					 + "0. 종료 \n"
					 + "--------------------------------- \n"
					 + "원하시는 메뉴를 왼쪽 번호로 선택해주세요. \n"
					 + "---------------------------------";
		
		while(true) {
			System.out.println(moviemenu);
			int choice = sc.nextInt();
			switch(choice) {
				case 1 : 
					System.out.println("더 배트맨 영화를 선택하셨습니다.");
					System.out.println("성인 인원 수를 입력해 주세요.");
					Anum = sc.nextInt();
					System.out.println("청소년 인원 수를 입력해 주세요");
					Tnum = sc.nextInt();
					
					Pnum = Anum + Tnum;
					System.out.printf("더 배트맨 %d 명 선택 하셨습니다. \n\n", Pnum); 
					break;
					
				case 2 : 
					System.out.println("이상한 나라의 수학자 영화를 선택하셨습니다.");
					System.out.println("성인 인원 수를 입력해 주세요.");
					Anum = sc.nextInt();
					System.out.println("청소년 인원 수를 입력해 주세요");
					Tnum = sc.nextInt();
					
					Pnum = Anum + Tnum;
					System.out.printf("이상한 나라의 수학자 %d 명 선택 하셨습니다. \n\n", Pnum); 
					break;
				case 3 : 
					System.out.println("언차티드 영화를 선택하셨습니다.");
					System.out.println("성인 인원 수를 입력해 주세요.");
					Anum = sc.nextInt();
					System.out.println("청소년 인원 수를 입력해 주세요");
					Tnum = sc.nextInt();
					
					Pnum = Anum + Tnum;
					System.out.printf("언차티드 %d 명 선택 하셨습니다. \n\n", Pnum); 
					break;
				case 4 : 
					System.out.println("블랙라이트 영화를 선택하셨습니다.");
					System.out.println("성인 인원 수를 입력해 주세요.");
					Anum = sc.nextInt();
					System.out.println("청소년 인원 수를 입력해 주세요");
					Tnum = sc.nextInt();
					
					Pnum = Anum + Tnum;
					System.out.printf("블랙 라이트 %d 명 선택 하셨습니다. \n\n", Pnum); 
					break;
				case 5 : 
					System.out.println("스파이더맨 : 노 웨이 홈 영화를 선택하셨습니다.");
					System.out.println("성인 인원 수를 입력해 주세요.");
					Anum = sc.nextInt();
					System.out.println("청소년 인원 수를 입력해 주세요");
					Tnum = sc.nextInt();
					
					Pnum = Anum + Tnum;
					System.out.printf("스파이더맨 : 노 웨이 홈  %d 명 선택 하셨습니다. \n\n", Pnum); 
					break;
					
				case 6 : sneckList1(); return; // 매점으로 리턴
				case 0 : pay1(); return; // 결제로 리턴
					
				default : 
					System.out.println("잘못 된 번호입니다.");
				}
		}
	}
		
	}


		