--------------------------------------------------------
--  파일이 생성됨 - 토요일-8월-20-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PERSISTENT_LOGINS
--------------------------------------------------------

  CREATE TABLE "PERSISTENT_LOGINS" 
   (	"USERNAME" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"SERIES" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"TOKEN" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"LAST_USED" TIMESTAMP (6)
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_CONTENT" 
   (	"CONTENT_NO" NUMBER, 
	"CHATROOM_ID" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"SEND_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RECEIVE_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"MESSAGE_CONTENT" VARCHAR2(4000) COLLATE "USING_NLS_COMP", 
	"MESSAGE_TIME" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_ROOM
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_ROOM" 
   (	"CHATROOM_ID" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"SEND_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RECEIVE_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"LAST_CHECK" NUMBER DEFAULT 0, 
	"CREATED_AT" DATE DEFAULT sysdate, 
	"DELETED_AT" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD" 
   (	"FB_NO" NUMBER, 
	"FB_P_NO" NUMBER DEFAULT null, 
	"FB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_TITLE" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_CREATED_AT" DATE DEFAULT sysdate, 
	"FB_UPDATED_AT" DATE DEFAULT sysdate, 
	"FB_READ_COUNT" NUMBER DEFAULT 0, 
	"FB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_ATTACHMENT" 
   (	"FBA_NO" NUMBER, 
	"FBA_FB_NO" NUMBER, 
	"FBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"TBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_COMMENT" 
   (	"FBC_NO" NUMBER, 
	"FBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBC_FB_NO" NUMBER, 
	"FBC_CREATED_AT" DATE DEFAULT sysdate, 
	"FBC_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER" 
   (	"M_NO" NUMBER, 
	"M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PASSWORD" VARCHAR2(512) COLLATE "USING_NLS_COMP", 
	"M_NAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PHONE" CHAR(11) COLLATE "USING_NLS_COMP", 
	"M_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER_ROLE" 
   (	"MR_AUTH" VARCHAR2(20) COLLATE "USING_NLS_COMP", 
	"MR_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD" 
   (	"NB_NO" NUMBER, 
	"NB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"NB_CREATED_AT" DATE DEFAULT sysdate, 
	"NB_UPDATE_AT" DATE DEFAULT sysdate, 
	"NB_READ_COUNT" NUMBER DEFAULT 0, 
	"NB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD_ATTACHMENT" 
   (	"NBA_NO" NUMBER, 
	"NBA_NB_NO" NUMBER, 
	"NBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER" 
   (	"P_NO" NUMBER, 
	"P_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"P_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_EXPLAN" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_LEAVE_DATE" DATE, 
	"P_RETURN_DATE" DATE, 
	"P_WRITE_DATE" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD" 
   (	"PB_NO" NUMBER, 
	"PB_P_NO" NUMBER, 
	"PB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PB_CREATED_AT" DATE DEFAULT sysdate, 
	"PB_UPDATED_AT" DATE DEFAULT sysdate, 
	"PB_READ_COUNT" NUMBER DEFAULT 0, 
	"PB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_COMMENT" 
   (	"PBC_NO" NUMBER, 
	"PBC_PB_NO" NUMBER, 
	"PBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBC_CREATED_AT" DATE DEFAULT sysdate, 
	"PBC_CONTENT" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_LOVE" 
   (	"PBL_NO" NUMBER, 
	"PBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBL_PB_NO" NUMBER, 
	"PBL_TYPE" NUMBER DEFAULT '0'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_PLAN" 
   (	"PP_NO" NUMBER, 
	"PP_P_NO" NUMBER, 
	"PP_TIME" TIMESTAMP (6), 
	"PP_PLACE_NAME" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PP_MEMO" VARCHAR2(2000) COLLATE "USING_NLS_COMP" DEFAULT null, 
	"PP_X" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PP_Y" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PP_DATE" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD" 
   (	"RB_NO" NUMBER, 
	"RB_P_NO" NUMBER, 
	"RB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"RB_CREATED_AT" DATE DEFAULT sysdate, 
	"RB_UPDATED_AT" DATE DEFAULT sysdate, 
	"RB_READ_COUNT" NUMBER DEFAULT 0, 
	"RB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_ATTACHMENT" 
   (	"RBA_NO" NUMBER, 
	"RBA_RB_NO" NUMBER, 
	"RBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_COMMENT" 
   (	"RBC_NO" NUMBER, 
	"RBC_RB_NO" NUMBER, 
	"RBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBC_CREATED_AT" DATE DEFAULT sysdate, 
	"RBC_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_LOVE" 
   (	"RBL_NO" NUMBER, 
	"RBL_RB_NO" NUMBER, 
	"RBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBL_TYPE" NUMBER DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
REM INSERTING into PERSISTENT_LOGINS
SET DEFINE OFF;
Insert into PERSISTENT_LOGINS (USERNAME,SERIES,TOKEN,LAST_USED) values ('tour@gmail.com','ZxU9m/y0tYfdtK1EjRlwXw==','sOHA3HWWesNq2AqTCA4iZg==',to_timestamp('22/08/19 12:15:06.654000000','RR/MM/DD HH24:MI:SSXFF'));
REM INSERTING into TMI_CHAT_CONTENT
SET DEFINE OFF;
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (23,'9qosc77J','ys1234@naver.com','ym1234@naver.com','as',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (65,'gecJ382r','ys1234@naver.com','honggd@naver.com','zzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (99,'9qosc77J','ys1234@naver.com','ym1234@naver.com','안녕',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (86,'7a89I0M0','ym1234@naver.com','honggd@naver.com','야',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (124,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (114,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (115,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅁㄴㅇㅁㅇㅁㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (116,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅇㅇㅇㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (117,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅁㄴㅇㅁㄴㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (118,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (119,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅁㄴㅇㅁㄴㅇㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (120,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (121,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (122,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (123,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (125,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (126,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (127,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (128,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (129,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (130,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (131,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (132,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (133,'gecJ382r','honggd@naver.com','ys1234@naver.com','asdada',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (134,'gecJ382r','honggd@naver.com','ys1234@naver.com','asdadsada',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (135,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (136,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (137,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅁㄴ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (138,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㄴㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (139,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅇㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (140,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅁㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (141,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅇㄴ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (142,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㄴㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (143,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅁㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (144,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅇㄴ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (145,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㄴㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (146,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅇㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (147,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅁㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (148,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (149,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (150,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (151,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅇㅁㄴㅇㄴㅁㅇㅁㄴ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (152,'440nICD9','honggd@naver.com','ks1234@naver.com','ㄴㅁㅇㅁㄴㅇㄴㅁㅇㅁㄴㅇㅇㄴㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (153,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅁㄴㅇㅁㄴㅇㄴㅁㅇㄴㅁㅁㄴㅇ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (154,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅋㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (155,'440nICD9','honggd@naver.com','ks1234@naver.com','ㅁㄴㅇㄴㅁㅇㄴㅁ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (156,'440nICD9','honggd@naver.com','ks1234@naver.com','ㄴㄴㄴㄴ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (157,'440nICD9','honggd@naver.com','ks1234@naver.com','아니',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (158,'440nICD9','honggd@naver.com','ks1234@naver.com','구우우웃',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (159,'440nICD9','honggd@naver.com','ks1234@naver.com','하아아아잇',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (160,'440nICD9','honggd@naver.com','ks1234@naver.com','좋아',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (161,'440nICD9','honggd@naver.com','ks1234@naver.com','굿굿',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (162,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (163,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋㅋ',to_date('22/08/20','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (34,'9qosc77J','ys1234@naver.com','ym1234@naver.com','zzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (43,'11709Hkb','TMI@gmail.com','ym1234@naver.com','qwe',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (52,'11709Hkb','TMI@gmail.com','ym1234@naver.com','123123',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (53,'11709Hkb','TMI@gmail.com','ym1234@naver.com','123123123123123',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (58,'11709Hkb','TMI@gmail.com','ym1234@naver.com','1112112',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (59,'11709Hkb','TMI@gmail.com','ym1234@naver.com','12123',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (66,'gecJ382r','ys1234@naver.com','honggd@naver.com','야',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (67,'gecJ382r','honggd@naver.com','ys1234@naver.com','왜',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (68,'gecJ382r','ys1234@naver.com','honggd@naver.com','뭐냐',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (69,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (70,'gecJ382r','ys1234@naver.com','honggd@naver.com','ㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (71,'gecJ382r','ys1234@naver.com','honggd@naver.com','ㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (72,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (73,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (74,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋㅋㅇㅋㅇㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (75,'gecJ382r','ys1234@naver.com','honggd@naver.com','뭔데',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (76,'gecJ382r','honggd@naver.com','ys1234@naver.com','ㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (77,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (78,'7a89I0M0','honggd@naver.com','ym1234@naver.com','12345',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (79,'7a89I0M0','ym1234@naver.com','honggd@naver.com','didi',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (80,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (81,'7a89I0M0','ym1234@naver.com','honggd@naver.com','aaaa',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (82,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㄴㅇㅁㅇㄴㅁ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (83,'7a89I0M0','ym1234@naver.com','honggd@naver.com','asdsadsad',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (84,'7a89I0M0','honggd@naver.com','ym1234@naver.com','ㅁㅇㄴㅁㅇㄴㅁㅇㄴ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (85,'7a89I0M0','ym1234@naver.com','honggd@naver.com','asdadsadsa',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (90,'7a89I0M0','honggd@naver.com','ym1234@naver.com','zz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (93,'7a89I0M0','ym1234@naver.com','honggd@naver.com','ㅇㅇㅇ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (94,'7a89I0M0','ym1234@naver.com','honggd@naver.com','ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (95,'7a89I0M0','ym1234@naver.com','honggd@naver.com','zㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (96,'7a89I0M0','ym1234@naver.com','honggd@naver.com','ㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (97,'7a89I0M0','ym1234@naver.com','honggd@naver.com','ㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (98,'gecJ382r','honggd@naver.com','ys1234@naver.com','ggzdzasddsasad',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (2,'gecJ382r','ys1234@naver.com','honggd@naver.com','sddss',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (3,'gecJ382r','ys1234@naver.com','honggd@naver.com','dsadasdsaadsasd',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (4,'gecJ382r','ys1234@naver.com','honggd@naver.com','하아ㅣㅣ아니암',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (5,'gecJ382r','ys1234@naver.com','honggd@naver.com','안녕',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (6,'gecJ382r','ys1234@naver.com','honggd@naver.com','ㄴㅇㅁㅇㄴ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (7,'9qosc77J','ys1234@naver.com','ym1234@naver.com','야',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (8,'9qosc77J','ys1234@naver.com','ym1234@naver.com','야야야야야야',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (9,'9qosc77J','ys1234@naver.com','ym1234@naver.com','ㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (10,'9qosc77J','ys1234@naver.com','ym1234@naver.com','ㅋㅋㅋㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (11,'9qosc77J','ys1234@naver.com','ym1234@naver.com','장난하냐',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (12,'9qosc77J','ys1234@naver.com','ym1234@naver.com','왜 위로 올라가지',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (13,'9qosc77J','ys1234@naver.com','ym1234@naver.com','ㅇㅇㅇㅇ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (14,'gecJ382r','ys1234@naver.com','honggd@naver.com','그럼이제 됌"?',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (15,'gecJ382r','ys1234@naver.com','honggd@naver.com','이렇게 보낼때',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (16,'gecJ382r','ys1234@naver.com','honggd@naver.com','ㅁㄹ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (17,'gecJ382r','ys1234@naver.com','honggd@naver.com','ㅁㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (18,'gecJ382r','ys1234@naver.com','honggd@naver.com','ㅇㅇㅇ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (19,'7a89I0M0','honggd@naver.com','ym1234@naver.com','zzzzzzzzzzzzzzzzzzzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (20,'7a89I0M0','honggd@naver.com','ym1234@naver.com','zzzzzzzzzzzzzzzzzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (24,'gecJ382r','ys1234@naver.com','honggd@naver.com','zzzzzzzzzzzzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (25,'9qosc77J','ys1234@naver.com','ym1234@naver.com','zzzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (26,'gecJ382r','ys1234@naver.com','honggd@naver.com','zzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (27,'9qosc77J','ys1234@naver.com','ym1234@naver.com','zzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (28,'9qosc77J','ys1234@naver.com','ym1234@naver.com','zzdzdz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (29,'gecJ382r','ys1234@naver.com','honggd@naver.com','zzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (30,'9qosc77J','ys1234@naver.com','ym1234@naver.com','z',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (31,'gecJ382r','ys1234@naver.com','honggd@naver.com','zzzzz',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (32,'gecJ382r','ys1234@naver.com','honggd@naver.com','왜 바로바로 출력이 안돼는거야',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (33,'9qosc77J','ys1234@naver.com','ym1234@naver.com','ㅋㅋㅋㅋ',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (87,'7a89I0M0','honggd@naver.com','ym1234@naver.com','뭐',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (88,'7a89I0M0','ym1234@naver.com','honggd@naver.com','가',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (89,'7a89I0M0','honggd@naver.com','ym1234@naver.com','나',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (91,'7a89I0M0','ym1234@naver.com','honggd@naver.com','뭔데',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (92,'7a89I0M0','honggd@naver.com','ym1234@naver.com','rnrnrnrnt',to_date('22/08/19','RR/MM/DD'));
REM INSERTING into TMI_CHAT_ROOM
SET DEFINE OFF;
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('gecJ382r','ys1234@naver.com','honggd@naver.com',0,to_date('22/08/18','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('440nICD9','honggd@naver.com','ks1234@naver.com',0,to_date('22/08/19','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('11709Hkb','TMI@gmail.com','ym1234@naver.com',0,to_date('22/08/19','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('7a89I0M0','honggd@naver.com','ym1234@naver.com',0,to_date('22/08/18','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('9qosc77J','ys1234@naver.com','ym1234@naver.com',0,to_date('22/08/19','RR/MM/DD'),null);
REM INSERTING into TMI_FRIEND_BOARD
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (224,0,'honggd@naver.com','asd',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),4);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (225,305,'honggd@naver.com','aaa',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (226,0,'ks1234@naver.com','123',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (227,0,'ks1234@naver.com','프랜드',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),3);
REM INSERTING into TMI_FRIEND_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_FRIEND_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_MEMBER
SET DEFINE OFF;
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (145,'danji@naver.com','뚱단지','$2a$10$gJ8gy68uQ8OkgfbamaMbFuvIZBFQK/gJ8R0ySzPWq5P0G2CpkgyQW','최단지','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (148,'bsj1234@naver.com','박서준','$2a$10$.dqpgfccHZYzqgypfgCEieScq4Za/hI/MGf7E5H2yXkJH5GkDtzp2','박서준','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (150,'jdh1234@naver.com','헤이즈','$2a$10$aC5RhqHvROdxjDATaZ1sWuNc4zOa6pB/SigyLe8upUQwYeDdaPLki','장다혜','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (151,'ey1225@naver.com','벤','$2a$10$sHGQePjPn1OBpgvsxW8OueYH9rw9O7hBhB3ZqVA.JdTGDSSZlKvBC','이은영','01024243535',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (152,'ym123@naver.com','용민이','$2a$10$fB05k22fHAPfZ57j0hMrKuJFFF1.e0wLqcdFGYUFLxNyIk/6CyCXy','김용민','01000000000',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (71,'admin@naver.com','관리자','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','관리자','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (72,'ym1234@naver.com','용가리민달팽이이','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','용민잉','01000000004',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (73,'ks1234@naver.com','이경석','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ks1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (169,'susu@naver.com','수수해','$2a$10$glTEdNXuriwnGl0vYdzeke9DCfZwPHbudJpuPYwG7TQNp5nRhFwOy','김수수','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (75,'mj1234@naver.com','권민지','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','mj1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (76,'ic1234@naver.com','전인찬','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ic1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (77,'th1234@naver.com','안태현','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','th1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (125,'TMI@gmail.com','이아엠티','$2a$10$NqyEATUKYfhm1Ny3Xe9QbOx3rwPE0vRsrjHbaGdLAr3UlP9EwELQa','티엠아이','01012349876',to_date('22/08/06','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (146,'dmin@naver.com','드드민','$2a$10$S0hwPdWyzhB13VmiXFynuugR5RMcvHfPt.S5NxMd7UfDWN9P2Zxom','이드민','01011112233',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (81,'honggd@naver.com','홍홍홍','$2a$10$EXTuRLRjK1z5DxbngxRhcOv74jtWGcspNLssI0sOvj2gGLs8a/OEO','홍길동','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (144,'munji@naver.com','냥펀치','$2a$10$FfpQpLtCgNR76oj4IF/MteY6NujD7u.Av/HGzDjoIqkvrbVEYIuQu','최먼지','01023234343',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (147,'tan1234@naver.com','탄왕자','$2a$10$7YBrrMRAEZFDsreQpMLyje1lAqkgkrQrYoKesS1PVz./N7a0oE/cq','최탄','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (149,'ml1234@naver.com','멜로망스','$2a$10$h90/YkQ5BKh/N8iPNeQ71.Izs0UH21U.0EUL5eDY/7TyIMCqxHIA.','김멜로','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (74,'ys1234@naver.com','최윤서','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ys1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (171,'bbob@naver.com','언니들','$2a$10$cioWla6xxJPodphV9x3EYursTl2JWToHt5lyC9joVGXtRQlpr0eu6','김밥맛','01098779877',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (172,'hb1234@naver.com','히밥','$2a$10$czi8ALh1GSp9gbOa7WJoUeD3HpXxAyaMm8KmbD4v5TMIVv6t2MgOu','김히밥','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (190,'ggy3381@naver.com','이방인','$2a$10$AQod//85GbV.2lPNMozH/OlikJfSfm2AxZI7BtKFZoXulF/0SYxeC','안태현','01076563381',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (170,'rjqnrdl@naver.com','꼬부기','$2a$10$cbQvotzgQ3Vv2INwOUaJXeamLiVTaIAdSsCxItGIVv8XC.lVVfyqa','김꼬북','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (173,'cat1234@naver.com','냥아치','$2a$10$4d.Lz8c8WDdOTwFHgaFM8OeRy0ZczRFFed7PfByUvW6QDYBp6zrfu','고먐미','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (175,'hari1234@naver.com','하리쨩','$2a$10$DGRdiHtg5/DH4N4d4DNLo.lBeae7FwixNUE08ERU4Gpg6TvLWb91W','임하리','01087487222',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (189,'dddks1234@naver.com','아무무','$2a$10$Yjbs/EevAX.JK6wpLJ7ONOdVvWEYtGfxrixrxKnoexxmb5VPqP83G','아무개','01054546223',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (174,'egg1234@naver.com','노른자','$2a$10$qkjiadYIIj/7PHqrsvufj.5uve069G8hCxJXo6AP3Cd3b1icJYE9u','김계란','01012345555',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (210,'tour@gmail.com','어투어투','$2a$10$F46Q3UcVg.ruP.Z/xKl9z.AQBEaqhDEElCDrmkNlfJ6Y34dkaBHDi','투어','01001020304',to_date('22/08/18','RR/MM/DD'));
REM INSERTING into TMI_MEMBER_ROLE
SET DEFINE OFF;
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_ADMIN','admin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','TMI@gmail.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','bbob@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','bsj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','cat1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','danji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','dddks1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','dmin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','egg1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ey1225@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ggy3381@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','hari1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','hb1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','honggd@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ic1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','jdh1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ks1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','mj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ml1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','munji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','rjqnrdl@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','susu@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','tan1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','th1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','tour@gmail.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ym1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ym123@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ys1234@naver.com');
REM INSERTING into TMI_NOTICE_BOARD
SET DEFINE OFF;
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (12,'ym1234@naver.com','테스트1',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (13,'honggd@naver.com','테스트1',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (14,'munji@naver.com','테스트2',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (15,'tan1234@naver.com','테스트3',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (16,'hb1234@naver.com','테스트4',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (17,'ys1234@naver.com','테스트5',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (18,'bbob@naver.com','테스트6',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (19,'ggy3381@naver.com','테스트7',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (20,'cat1234@naver.com','테스트8',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (21,'hari1234@naver.com','테스트9',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (22,'dddks1234@naver.com','테스트10',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (23,'egg1234@naver.com','테스트11',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (1,'ym1234@naver.com','테스트1',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (28,'admin@naver.com',null,to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),1);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (24,'admin@naver.com','ㅇㅇ',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),1);
REM INSERTING into TMI_NOTICE_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER
SET DEFINE OFF;
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (272,'ym1234@naver.com','테스트 일정',null,to_date('22/09/01','RR/MM/DD'),to_date('22/09/05','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'));
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (0,'admin@naver.com','0',null,to_date('22/08/18','RR/MM/DD'),to_date('22/08/18','RR/MM/DD'),null);
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (305,'honggd@naver.com','asd','asd',to_date('22/08/17','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),to_date('22/08/17','RR/MM/DD'));
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (332,'ym1234@naver.com','테스투 ~','ㅋㅋ',to_date('22/08/01','RR/MM/DD'),to_date('22/08/03','RR/MM/DD'),to_date('22/08/18','RR/MM/DD'));
REM INSERTING into TMI_PLANNER_BOARD
SET DEFINE OFF;
Insert into TMI_PLANNER_BOARD (PB_NO,PB_P_NO,PB_M_EMAIL,PB_TITLE,PB_CREATED_AT,PB_UPDATED_AT,PB_READ_COUNT) values (2,0,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_PLANNER_BOARD (PB_NO,PB_P_NO,PB_M_EMAIL,PB_TITLE,PB_CREATED_AT,PB_UPDATED_AT,PB_READ_COUNT) values (3,0,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_PLANNER_BOARD (PB_NO,PB_P_NO,PB_M_EMAIL,PB_TITLE,PB_CREATED_AT,PB_UPDATED_AT,PB_READ_COUNT) values (4,0,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_PLANNER_BOARD (PB_NO,PB_P_NO,PB_M_EMAIL,PB_TITLE,PB_CREATED_AT,PB_UPDATED_AT,PB_READ_COUNT) values (5,0,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
REM INSERTING into TMI_PLANNER_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_LOVE
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_PLAN
SET DEFINE OFF;
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (393,272,to_timestamp('70/01/01 14:00:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 강남지원 1관',null,'127.03285','37.498936',to_date('22/09/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (394,272,to_timestamp('70/01/01 15:40:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'CGV 강남',null,'127.02639','37.501656',to_date('22/09/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (395,272,to_timestamp('70/01/01 16:30:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'다이소 강남본점',null,'127.029045','37.49595',to_date('22/09/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (396,272,to_timestamp('70/01/01 15:10:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'신라스테이 역삼',null,'127.041306','37.504974',to_date('22/09/02','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (397,272,to_timestamp('70/01/01 14:05:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'영풍문고 강남역점',null,'127.02743','37.49916',to_date('22/09/02','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (398,272,to_timestamp('70/01/01 14:10:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'홍대입구역 2호선',null,'126.92378','37.55687',to_date('22/09/03','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (399,272,to_timestamp('70/01/01 23:10:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'CGV 홍대',null,'126.92262','37.556503',to_date('22/09/03','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (400,272,to_timestamp('70/01/01 14:05:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'홍대패션거리',null,'126.923584','37.555397',to_date('22/09/04','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (457,305,null,'울산KH정보교육원',null,'129.3108','35.535015',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (458,305,null,'KH정보교육원 강남지원 1관',null,'127.03285','37.498936',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (615,332,to_timestamp('70/01/01 02:47:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'울산KH정보교육원','1','129.3108','35.535015',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (616,332,to_timestamp('70/01/01 00:50:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'울산KH정보교육원','2','129.3108','35.535015',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (617,332,to_timestamp('70/01/01 00:49:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 강남지원 1관','3','127.03285','37.498936',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (618,332,to_timestamp('70/01/01 04:47:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 강남지원 1관','4','127.03285','37.498936',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (619,332,to_timestamp('70/01/01 00:48:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 종로지원','1','126.98313','37.567917',to_date('22/08/02','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (620,332,to_timestamp('70/01/01 01:47:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 종로지원','2','126.98313','37.567917',to_date('22/08/02','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (621,332,to_timestamp('70/01/01 00:48:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 당산지원','3','126.89676','37.53391',to_date('22/08/02','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (622,332,to_timestamp('70/01/01 06:47:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 당산지원','4','126.89676','37.53391',to_date('22/08/02','RR/MM/DD'));
REM INSERTING into TMI_REVIEW_BOARD
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (46,305,'honggd@naver.com','테스트',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),3);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (47,0,'ks1234@naver.com','후기',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),1);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (45,332,'ym1234@naver.com','test',to_date('22/08/19','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),3);
REM INSERTING into TMI_REVIEW_BOARD_ATTACHMENT
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (43,46,'images (1).jpg','20220819_121850030_659.jpg',to_date('22/08/19','RR/MM/DD'));
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (42,45,'ddd.PNG','20220819_113330448_726.PNG',to_date('22/08/19','RR/MM/DD'));
REM INSERTING into TMI_REVIEW_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD_LOVE
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (64,46,'honggd@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (66,46,'ks1234@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (67,46,'admin@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (69,46,'TMI@gmail.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (65,46,'ym1234@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (68,46,'mj1234@naver.com',1);
--------------------------------------------------------
--  DDL for Index SYS_C0042334
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0042334" ON "PERSISTENT_LOGINS" ("SERIES")
--------------------------------------------------------
--  DDL for Index PK_CHAT_CONTENT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CHAT_CONTENT" ON "TMI_CHAT_CONTENT" ("CONTENT_NO")
--------------------------------------------------------
--  DDL for Index PK_CHAT_ROOM
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CHAT_ROOM" ON "TMI_CHAT_ROOM" ("CHATROOM_ID")
--------------------------------------------------------
--  DDL for Index PK_FB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FB_NO" ON "TMI_FRIEND_BOARD" ("FB_NO")
--------------------------------------------------------
--  DDL for Index PK_FBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBA_NO" ON "TMI_FRIEND_BOARD_ATTACHMENT" ("FBA_NO")
--------------------------------------------------------
--  DDL for Index PK_FBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBC_NO" ON "TMI_FRIEND_BOARD_COMMENT" ("FBC_NO")
--------------------------------------------------------
--  DDL for Index PK_M_EMAIL
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_M_EMAIL" ON "TMI_MEMBER" ("M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_MR_AUTH
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MR_AUTH" ON "TMI_MEMBER_ROLE" ("MR_AUTH", "MR_M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_NB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NB_NO" ON "TMI_NOTICE_BOARD" ("NB_NO")
--------------------------------------------------------
--  DDL for Index PK_NBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NBA_NO" ON "TMI_NOTICE_BOARD_ATTACHMENT" ("NBA_NO")
--------------------------------------------------------
--  DDL for Index PK_P_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_P_NO" ON "TMI_PLANNER" ("P_NO")
--------------------------------------------------------
--  DDL for Index PK_PB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PB_NO" ON "TMI_PLANNER_BOARD" ("PB_NO")
--------------------------------------------------------
--  DDL for Index PK_PBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBC_NO" ON "TMI_PLANNER_BOARD_COMMENT" ("PBC_NO")
--------------------------------------------------------
--  DDL for Index PK_PBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBL_LOVE_NO" ON "TMI_PLANNER_BOARD_LOVE" ("PBL_NO")
--------------------------------------------------------
--  DDL for Index PK_PP_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PP_NO" ON "TMI_PLANNER_PLAN" ("PP_NO")
--------------------------------------------------------
--  DDL for Index PK_RB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RB_NO" ON "TMI_REVIEW_BOARD" ("RB_NO")
--------------------------------------------------------
--  DDL for Index PK_RBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBA_NO" ON "TMI_REVIEW_BOARD_ATTACHMENT" ("RBA_NO")
--------------------------------------------------------
--  DDL for Index PK_RBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBC_NO" ON "TMI_REVIEW_BOARD_COMMENT" ("RBC_NO")
--------------------------------------------------------
--  DDL for Index PK_RBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBL_LOVE_NO" ON "TMI_REVIEW_BOARD_LOVE" ("RBL_NO")
--------------------------------------------------------
--  Constraints for Table PERSISTENT_LOGINS
--------------------------------------------------------

  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("USERNAME" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("TOKEN" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("LAST_USED" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" ADD PRIMARY KEY ("SERIES")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("CONTENT_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("CHATROOM_ID" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("SEND_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("RECEIVE_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "PK_CHAT_CONTENT" PRIMARY KEY ("CONTENT_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CHATROOM_ID" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("SEND_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("RECEIVE_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "PK_CHAT_ROOM" PRIMARY KEY ("CHATROOM_ID")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" MODIFY ("FB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "PK_FB_NO" PRIMARY KEY ("FB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_FBA_NO" PRIMARY KEY ("FBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" MODIFY ("FBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "PK_FBC_NO" PRIMARY KEY ("FBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PASSWORD" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PHONE" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" ADD CONSTRAINT "PK_M_EMAIL" PRIMARY KEY ("M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" MODIFY ("MR_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "PK_MR_AUTH" PRIMARY KEY ("MR_AUTH", "MR_M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" MODIFY ("NB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "PK_NB_NO" PRIMARY KEY ("NB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_NBA_NO" PRIMARY KEY ("NBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" MODIFY ("P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_TITLE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_LEAVE_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_RETURN_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "PK_P_NO" PRIMARY KEY ("P_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "PK_PB_NO" PRIMARY KEY ("PB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" MODIFY ("PBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "PK_PBC_NO" PRIMARY KEY ("PBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "PK_PBL_LOVE_NO" PRIMARY KEY ("PBL_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_X" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_Y" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "PK_PP_NO" PRIMARY KEY ("PP_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" MODIFY ("RB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "PK_RB_NO" PRIMARY KEY ("RB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_RBA_NO" PRIMARY KEY ("RBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" MODIFY ("RBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "PK_RBC_NO" PRIMARY KEY ("RBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "PK_RBL_LOVE_NO" PRIMARY KEY ("RBL_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "FK_CHAT_CONTENT_CHATROOM_ID" FOREIGN KEY ("CHATROOM_ID")
	  REFERENCES "TMI_CHAT_ROOM" ("CHATROOM_ID") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_SEND_EMAIL" FOREIGN KEY ("SEND_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_RECEIVE_EMAIL" FOREIGN KEY ("RECEIVE_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_P_NO" FOREIGN KEY ("FB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_M_EMAIL" FOREIGN KEY ("FB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_FB_NO" FOREIGN KEY ("FBA_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_COMENT_RB_NO" FOREIGN KEY ("FBC_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_M_EMAIL" FOREIGN KEY ("FBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "FK_MEMBER_ROLE_M_EMAIL" FOREIGN KEY ("MR_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "FK_NOTICE_BOARD_M_EMAIL" FOREIGN KEY ("NB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_NB_NO" FOREIGN KEY ("NBA_NB_NO")
	  REFERENCES "TMI_NOTICE_BOARD" ("NB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "FK_PLANNER_M_EMAIL" FOREIGN KEY ("P_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_P_NO" FOREIGN KEY ("PB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_M_EMAIL" FOREIGN KEY ("PB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_PB_NO" FOREIGN KEY ("PBC_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_M_EMAIL" FOREIGN KEY ("PBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_PB_NO" FOREIGN KEY ("PBL_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("PBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "FK_PLANNER_PLAN_P_NO" FOREIGN KEY ("PP_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_P_NO" FOREIGN KEY ("RB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_M_EMAIL" FOREIGN KEY ("RB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_REVIEW_BOARD_ATTACHMENT_RB_NO" FOREIGN KEY ("RBA_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_COMENT_RB_NO" FOREIGN KEY ("RBC_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_M_EMAIL" FOREIGN KEY ("RBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_RB_NO" FOREIGN KEY ("RBL_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("RBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
