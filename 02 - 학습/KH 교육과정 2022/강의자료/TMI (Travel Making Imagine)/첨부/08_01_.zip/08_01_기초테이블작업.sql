--------------------------------------------------------
--  파일이 생성됨 - 월요일-8월-01-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PERSISTENT_LOGINS
--------------------------------------------------------

  CREATE TABLE "PERSISTENT_LOGINS" 
   (	"USERNAME" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"SERIES" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"TOKEN" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"LAST_USED" TIMESTAMP (6)
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_CONTENT" 
   (	"CC_NO" NUMBER, 
	"CC_CR_TITLE" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"CC_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"CC_MESSAGE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"CC_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_ROOM
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_ROOM" 
   (	"CR_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"CR_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"CR_FB_NO" NUMBER, 
	"CR_CREATED_AT" DATE DEFAULT sysdate, 
	"CR_LAST_CHECK" NUMBER, 
	"CR_DELETED_AT" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD" 
   (	"FB_NO" NUMBER, 
	"FB_P_NO" NUMBER, 
	"FB_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_TITLE" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_CONTENT" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_CREATED_AT" DATE DEFAULT sysdate, 
	"FB_UPDATED_AT" DATE DEFAULT sysdate, 
	"FB_READ_COUNT" NUMBER DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_ATTACHMENT" 
   (	"FBA_NO" NUMBER, 
	"FBA_FB_NO" NUMBER, 
	"FBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"TBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_COMMENT" 
   (	"FBC_NO" NUMBER, 
	"FBC_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBC_FB_NO" NUMBER, 
	"FBC_CREATED_AT" DATE DEFAULT sysdate, 
	"FBC_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER" 
   (	"M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_NO" NUMBER, 
	"M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PASSWORD" VARCHAR2(512) COLLATE "USING_NLS_COMP", 
	"M_NAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PHONE" CHAR(11) COLLATE "USING_NLS_COMP", 
	"M_SOCIALTYPE" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_CREATED_AT" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER_ROLE" 
   (	"MR_AUTH" VARCHAR2(20) COLLATE "USING_NLS_COMP", 
	"MR_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD" 
   (	"NB_NO" NUMBER, 
	"NB_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"NB_CONTENT" VARCHAR2(4000) COLLATE "USING_NLS_COMP", 
	"NB_CREATED_AT" DATE DEFAULT sysdate, 
	"NB_UPDATE_AT" DATE DEFAULT sysdate, 
	"NB_READ_COUNT" NUMBER DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD_ATTACHMENT" 
   (	"NBA_NO" NUMBER, 
	"NBA_NB_NO" NUMBER, 
	"NBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER" 
   (	"P_NO" NUMBER, 
	"P_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"P_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_EXPLAN" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_LEAVE_DATE" DATE, 
	"P_RETURN_DATE" DATE, 
	"P_WRITE_DATE" DATE DEFAULT sysdate, 
	"P_SHARE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT 'N'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD" 
   (	"PB_NO" NUMBER, 
	"PB_P_NO" NUMBER, 
	"PB_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PB_CONTENT" VARCHAR2(4000) COLLATE "USING_NLS_COMP", 
	"PB_CREATED_AT" DATE DEFAULT sysdate, 
	"PB_UPDATED_AT" DATE DEFAULT sysdate, 
	"PB_READ_COUNT" NUMBER DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_COMMENT" 
   (	"PBC_NO" NUMBER, 
	"PBC_PB_NO" NUMBER, 
	"PBC_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBC_CREATED_AT" DATE DEFAULT sysdate, 
	"PBC_CONTENT" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_LOVE" 
   (	"PBL_LOVE_NO" NUMBER, 
	"PBL_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBL_PB_NO" NUMBER, 
	"PBL_LOVETYPE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT '0'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_PLAN" 
   (	"PP_NO" NUMBER, 
	"PP_P_NO" NUMBER, 
	"PP_DATE" DATE DEFAULT sysdate, 
	"PP_PLACE_NAME" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PP_MEMO" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PP_X" NUMBER, 
	"PP_Y" NUMBER
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD" 
   (	"RB_NO" NUMBER, 
	"RB_P_NO" NUMBER, 
	"RB_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"RB_CONTENT" VARCHAR2(4000) COLLATE "USING_NLS_COMP", 
	"RB_CREATED_AT" DATE DEFAULT sysdate, 
	"RB_UPDATED_AT" DATE DEFAULT sysdate, 
	"RB_READ_COUNT" NUMBER DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_ATTACHMENT" 
   (	"RBA_NO" NUMBER, 
	"RBA_RB_NO" NUMBER, 
	"RBA_ATTACHMENT_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_ATTACHMENT_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_ATTACHMENT_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_COMMENT" 
   (	"RBC_NO" NUMBER, 
	"RBC_RB_NO" NUMBER, 
	"RBC_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_COMMENT_CREATE_AT" DATE DEFAULT sysdate, 
	"RB_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_LOVE" 
   (	"RBL_LOVE_NO" NUMBER, 
	"RBL_RB_NO" NUMBER, 
	"RBL_M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBL_LOVETYPE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
REM INSERTING into PERSISTENT_LOGINS
SET DEFINE OFF;
REM INSERTING into TMI_CHAT_CONTENT
SET DEFINE OFF;
REM INSERTING into TMI_CHAT_ROOM
SET DEFINE OFF;
REM INSERTING into TMI_FRIEND_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_FRIEND_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_FRIEND_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_MEMBER
SET DEFINE OFF;
REM INSERTING into TMI_MEMBER_ROLE
SET DEFINE OFF;
REM INSERTING into TMI_NOTICE_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_NOTICE_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_LOVE
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_PLAN
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD_LOVE
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C0042052
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0042052" ON "PERSISTENT_LOGINS" ("SERIES")
--------------------------------------------------------
--  DDL for Index PK_CC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CC_NO" ON "TMI_CHAT_CONTENT" ("CC_NO")
--------------------------------------------------------
--  DDL for Index PK_CHAT_MEMBER
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CHAT_MEMBER" ON "TMI_CHAT_ROOM" ("CR_TITLE", "CR_M_NICKNAME")
--------------------------------------------------------
--  DDL for Index PK_FB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FB_NO" ON "TMI_FRIEND_BOARD" ("FB_NO")
--------------------------------------------------------
--  DDL for Index PK_FBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBA_NO" ON "TMI_FRIEND_BOARD_ATTACHMENT" ("FBA_NO")
--------------------------------------------------------
--  DDL for Index PK_FBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBC_NO" ON "TMI_FRIEND_BOARD_COMMENT" ("FBC_NO")
--------------------------------------------------------
--  DDL for Index PK_M_NICKNAME
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_M_NICKNAME" ON "TMI_MEMBER" ("M_NICKNAME")
--------------------------------------------------------
--  DDL for Index PK_MR_AUTH
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MR_AUTH" ON "TMI_MEMBER_ROLE" ("MR_AUTH", "MR_M_NICKNAME")
--------------------------------------------------------
--  DDL for Index PK_NB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NB_NO" ON "TMI_NOTICE_BOARD" ("NB_NO")
--------------------------------------------------------
--  DDL for Index PK_NBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NBA_NO" ON "TMI_NOTICE_BOARD_ATTACHMENT" ("NBA_NO")
--------------------------------------------------------
--  DDL for Index PK_P_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_P_NO" ON "TMI_PLANNER" ("P_NO")
--------------------------------------------------------
--  DDL for Index PK_PB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PB_NO" ON "TMI_PLANNER_BOARD" ("PB_NO")
--------------------------------------------------------
--  DDL for Index PK_PBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBC_NO" ON "TMI_PLANNER_BOARD_COMMENT" ("PBC_NO")
--------------------------------------------------------
--  DDL for Index PK_PBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBL_LOVE_NO" ON "TMI_PLANNER_BOARD_LOVE" ("PBL_LOVE_NO")
--------------------------------------------------------
--  DDL for Index PK_PP_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PP_NO" ON "TMI_PLANNER_PLAN" ("PP_NO")
--------------------------------------------------------
--  DDL for Index PK_RB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RB_NO" ON "TMI_REVIEW_BOARD" ("RB_NO")
--------------------------------------------------------
--  DDL for Index PK_RBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBA_NO" ON "TMI_REVIEW_BOARD_ATTACHMENT" ("RBA_NO")
--------------------------------------------------------
--  DDL for Index PK_RBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBC_NO" ON "TMI_REVIEW_BOARD_COMMENT" ("RBC_NO")
--------------------------------------------------------
--  DDL for Index PK_RBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBL_LOVE_NO" ON "TMI_REVIEW_BOARD_LOVE" ("RBL_LOVE_NO")
--------------------------------------------------------
--  Constraints for Table PERSISTENT_LOGINS
--------------------------------------------------------

  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("USERNAME" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("TOKEN" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("LAST_USED" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" ADD PRIMARY KEY ("SERIES")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("CC_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "PK_CC_NO" PRIMARY KEY ("CC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CR_TITLE" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CR_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "PK_CHAT_MEMBER" PRIMARY KEY ("CR_TITLE", "CR_M_NICKNAME")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" MODIFY ("FB_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD" MODIFY ("FB_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "PK_FB_NO" PRIMARY KEY ("FB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_FBA_NO" PRIMARY KEY ("FBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" MODIFY ("FBC_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "PK_FBC_NO" PRIMARY KEY ("FBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PASSWORD" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PHONE" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_SOCIALTYPE" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_CREATED_AT" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" ADD CONSTRAINT "PK_M_NICKNAME" PRIMARY KEY ("M_NICKNAME")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" MODIFY ("MR_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "PK_MR_AUTH" PRIMARY KEY ("MR_AUTH", "MR_M_NICKNAME")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" MODIFY ("NB_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "PK_NB_NO" PRIMARY KEY ("NB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_NBA_NO" PRIMARY KEY ("NBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" MODIFY ("P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_TITLE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_LEAVE_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_RETURN_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "PK_P_NO" PRIMARY KEY ("P_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "PK_PB_NO" PRIMARY KEY ("PB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" MODIFY ("PBC_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "PK_PBC_NO" PRIMARY KEY ("PBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_LOVE_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "PK_PBL_LOVE_NO" PRIMARY KEY ("PBL_LOVE_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_X" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_Y" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "PK_PP_NO" PRIMARY KEY ("PP_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" MODIFY ("RB_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD" MODIFY ("RB_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "PK_RB_NO" PRIMARY KEY ("RB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_ATTACHMENT_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_ATTACHMENT_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_RBA_NO" PRIMARY KEY ("RBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" MODIFY ("RBC_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "PK_RBC_NO" PRIMARY KEY ("RBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_LOVE_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "PK_RBL_LOVE_NO" PRIMARY KEY ("RBL_LOVE_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "FK_CHAT_CONTENT" FOREIGN KEY ("CC_CR_TITLE", "CC_M_NICKNAME")
	  REFERENCES "TMI_CHAT_ROOM" ("CR_TITLE", "CR_M_NICKNAME") ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_M_NICKNAME" FOREIGN KEY ("CR_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_FB_NO" FOREIGN KEY ("CR_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_P_NO" FOREIGN KEY ("FB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_M_NICKNAME" FOREIGN KEY ("FB_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_FB_NO" FOREIGN KEY ("FBA_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_COMENT_RB_NO" FOREIGN KEY ("FBC_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_M_NICKNAME" FOREIGN KEY ("FBC_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "FK_MEMBER_ROLE_M_NICKNAME" FOREIGN KEY ("MR_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "FK_NOTICE_BOARD_M_NICKNAME" FOREIGN KEY ("NB_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_NB_NO" FOREIGN KEY ("NBA_NB_NO")
	  REFERENCES "TMI_NOTICE_BOARD" ("NB_NO") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "FK_PLANNER_M_NICKNAME" FOREIGN KEY ("P_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_P_NO" FOREIGN KEY ("PB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_M_NICKNAME" FOREIGN KEY ("PB_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_PB_NO" FOREIGN KEY ("PBC_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_M_NICKNAME" FOREIGN KEY ("PBC_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_PB_NO" FOREIGN KEY ("PBL_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_M_NICKNAME" FOREIGN KEY ("PBL_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "FK_PLANNER_PLAN_P_NO" FOREIGN KEY ("PP_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_P_NO" FOREIGN KEY ("RB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_M_NICKNAME" FOREIGN KEY ("RB_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_REVIEW_BOARD_ATTACHMENT_RB_NO" FOREIGN KEY ("RBA_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_COMENT_RB_NO" FOREIGN KEY ("RBC_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_M_NICKNAME" FOREIGN KEY ("RBC_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_RB_NO" FOREIGN KEY ("RBL_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_M_NICKNAME" FOREIGN KEY ("RBL_M_NICKNAME")
	  REFERENCES "TMI_MEMBER" ("M_NICKNAME") ON DELETE CASCADE ENABLE
