--------------------------------------------------------
--  파일이 생성됨 - 목요일-8월-18-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PERSISTENT_LOGINS
--------------------------------------------------------

  CREATE TABLE "PERSISTENT_LOGINS" 
   (	"USERNAME" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"SERIES" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"TOKEN" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"LAST_USED" TIMESTAMP (6)
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_CONTENT" 
   (	"CONTENT_NO" NUMBER, 
	"CHATROOM_ID" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"SEND_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RECEIVE_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"MESSAGE_CONTENT" VARCHAR2(4000) COLLATE "USING_NLS_COMP", 
	"MESSAGE_TIME" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_ROOM
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_ROOM" 
   (	"CHATROOM_ID" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"SEND_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RECEIVE_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"LAST_CHECK" NUMBER DEFAULT 0, 
	"CREATED_AT" DATE DEFAULT sysdate, 
	"DELETED_AT" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD" 
   (	"FB_NO" NUMBER, 
	"FB_P_NO" NUMBER DEFAULT null, 
	"FB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_TITLE" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_CREATED_AT" DATE DEFAULT sysdate, 
	"FB_UPDATED_AT" DATE DEFAULT sysdate, 
	"FB_READ_COUNT" NUMBER DEFAULT 0, 
	"FB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_ATTACHMENT" 
   (	"FBA_NO" NUMBER, 
	"FBA_FB_NO" NUMBER, 
	"FBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"TBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_COMMENT" 
   (	"FBC_NO" NUMBER, 
	"FBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBC_FB_NO" NUMBER, 
	"FBC_CREATED_AT" DATE DEFAULT sysdate, 
	"FBC_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER" 
   (	"M_NO" NUMBER, 
	"M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PASSWORD" VARCHAR2(512) COLLATE "USING_NLS_COMP", 
	"M_NAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PHONE" CHAR(11) COLLATE "USING_NLS_COMP", 
	"M_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER_ROLE" 
   (	"MR_AUTH" VARCHAR2(20) COLLATE "USING_NLS_COMP", 
	"MR_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD" 
   (	"NB_NO" NUMBER, 
	"NB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"NB_CONTENT" VARCHAR2(4000) COLLATE "USING_NLS_COMP", 
	"NB_CREATED_AT" DATE DEFAULT sysdate, 
	"NB_UPDATE_AT" DATE DEFAULT sysdate, 
	"NB_READ_COUNT" NUMBER DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD_ATTACHMENT" 
   (	"NBA_NO" NUMBER, 
	"NBA_NB_NO" NUMBER, 
	"NBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER" 
   (	"P_NO" NUMBER, 
	"P_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"P_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_EXPLAN" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_LEAVE_DATE" DATE, 
	"P_RETURN_DATE" DATE, 
	"P_WRITE_DATE" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD" 
   (	"PB_NO" NUMBER, 
	"PB_P_NO" NUMBER, 
	"PB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PB_CREATED_AT" DATE DEFAULT sysdate, 
	"PB_UPDATED_AT" DATE DEFAULT sysdate, 
	"PB_READ_COUNT" NUMBER DEFAULT 0, 
	"PB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_COMMENT" 
   (	"PBC_NO" NUMBER, 
	"PBC_PB_NO" NUMBER, 
	"PBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBC_CREATED_AT" DATE DEFAULT sysdate, 
	"PBC_CONTENT" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_LOVE" 
   (	"PBL_LOVE_NO" NUMBER, 
	"PBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBL_PB_NO" NUMBER, 
	"PBL_LOVETYPE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT '0'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_PLAN" 
   (	"PP_NO" NUMBER, 
	"PP_P_NO" NUMBER, 
	"PP_TIME" TIMESTAMP (6), 
	"PP_PLACE_NAME" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PP_MEMO" VARCHAR2(2000) COLLATE "USING_NLS_COMP" DEFAULT null, 
	"PP_X" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PP_Y" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PP_DATE" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD" 
   (	"RB_NO" NUMBER, 
	"RB_P_NO" NUMBER, 
	"RB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"RB_CREATED_AT" DATE DEFAULT sysdate, 
	"RB_UPDATED_AT" DATE DEFAULT sysdate, 
	"RB_READ_COUNT" NUMBER DEFAULT 0, 
	"RB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_ATTACHMENT" 
   (	"RBA_NO" NUMBER, 
	"RBA_RB_NO" NUMBER, 
	"RBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_COMMENT" 
   (	"RBC_NO" NUMBER, 
	"RBC_RB_NO" NUMBER, 
	"RBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBC_CREATED_AT" DATE DEFAULT sysdate, 
	"RBC_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_LOVE" 
   (	"RBL_NO" NUMBER, 
	"RBL_RB_NO" NUMBER, 
	"RBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBL_TYPE" NUMBER DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
REM INSERTING into PERSISTENT_LOGINS
SET DEFINE OFF;
Insert into PERSISTENT_LOGINS (USERNAME,SERIES,TOKEN,LAST_USED) values ('TMI@gmail.com','B0mzEN7E8NQt+vMMbGUxFg==','yMSRwHnJJuMww6wdrGT+Sw==',to_timestamp('22/08/16 00:20:55.141000000','RR/MM/DD HH24:MI:SSXFF'));
REM INSERTING into TMI_CHAT_CONTENT
SET DEFINE OFF;
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (101,'WizN3xSK','admin@naver.com','ys1234@naver.com','aaaaaaaaaa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (102,'WizN3xSK','admin@naver.com','ys1234@naver.com','sadadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (103,'WizN3xSK','admin@naver.com','ys1234@naver.com','asdasdas',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (104,'WizN3xSK','ys1234@naver.com','admin@naver.com','asdasdaadsads',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (105,'WizN3xSK','ys1234@naver.com','admin@naver.com','asdasdasasdasd',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (106,'WizN3xSK','admin@naver.com','ys1234@naver.com','asdasdasd',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (107,'WizN3xSK','admin@naver.com','ys1234@naver.com','asdadasd',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (108,'WizN3xSK','ys1234@naver.com','admin@naver.com','asdadadas',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (109,'6etYO2E4','ym1234@naver.com','ys1234@naver.com','zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (110,'6etYO2E4','ym1234@naver.com','ys1234@naver.com','최근메세지',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (111,'6Q0j1m1e','jdh1234@naver.com','ys1234@naver.com','adadsadasdsadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (56,'M4785A08','ys1234@naver.com','honggd@naver.com','sdaddsadasd',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (57,'M4785A08','ys1234@naver.com','honggd@naver.com','dsadsdsaa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (58,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsadasdsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (59,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsadadads',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (60,'M4785A08','ys1234@naver.com','honggd@naver.com','asdadasdad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (61,'M4785A08','ys1234@naver.com','honggd@naver.com','dsadasdsadsadsadsadsadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (62,'M4785A08','ys1234@naver.com','honggd@naver.com','asdads',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (63,'M4785A08','ys1234@naver.com','honggd@naver.com','asdadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (64,'M4785A08','ys1234@naver.com','honggd@naver.com','asdadsada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (65,'M4785A08','honggd@naver.com','ys1234@naver.com','??',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (66,'M4785A08','ys1234@naver.com','honggd@naver.com','zzzzzasdas',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (67,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (70,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (71,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadsadad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (72,'M4785A08','honggd@naver.com','ys1234@naver.com','asdsadas',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (73,'M4785A08','honggd@naver.com','ys1234@naver.com','asdsadadsadsada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (74,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsdsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (75,'M4785A08','honggd@naver.com','ys1234@naver.com','1234321321321',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (76,'M4785A08','honggd@naver.com','ys1234@naver.com','asdsadsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (77,'M4785A08','honggd@naver.com','ys1234@naver.com','sadadsadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (78,'M4785A08','ys1234@naver.com','honggd@naver.com','asdadsadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (79,'M4785A08','ys1234@naver.com','honggd@naver.com','asdadada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (80,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadsadsadsadsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (81,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadsadsadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (82,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadsadsada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (83,'M4785A08','honggd@naver.com','ys1234@naver.com','asdsada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (84,'M4785A08','ys1234@naver.com','honggd@naver.com','asdasdsadsadadada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (85,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsadsadsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (86,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadadad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (87,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadadsadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (88,'M4785A08','ys1234@naver.com','honggd@naver.com','saddadsadada',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (89,'M4785A08','ys1234@naver.com','honggd@naver.com','asdadsadsadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (90,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadadad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (91,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsadsadsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (92,'M4785A08','ys1234@naver.com','honggd@naver.com','asdasdsadsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (51,'M4785A08','ys1234@naver.com','honggd@naver.com','sdasadsadsadsadsadas',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (52,'M4785A08','ys1234@naver.com','honggd@naver.com','zzzzzzzzzzzzzzzzzzzzzzzzzzzzzz',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (68,'M4785A08','ys1234@naver.com','honggd@naver.com','ㅇㅁㄴㅁㄴㅇㅁㅇㄴ',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (69,'M4785A08','ys1234@naver.com','honggd@naver.com','ㅁㄴㅇㅁㄴㅇㅇ',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (121,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsadsad',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (122,'dUBuOO19','honggd@naver.com','admin@naver.com','관리자님',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (123,'dUBuOO19','admin@naver.com','honggd@naver.com','ㅋㅋ',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (124,'6etYO2E4','ym1234@naver.com','ys1234@naver.com','안녕',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (125,'M4785A08','honggd@naver.com','ys1234@naver.com','안녕ㅋㅋ',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (126,'M4785A08','honggd@naver.com','ys1234@naver.com','야',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (127,'M4785A08','ys1234@naver.com','honggd@naver.com','야야',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (53,'M4785A08','ys1234@naver.com','honggd@naver.com','asdsadasdadsadsadsad',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (54,'M4785A08','honggd@naver.com','ys1234@naver.com','asdadsadsadadsa',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CONTENT_NO,CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,MESSAGE_CONTENT,MESSAGE_TIME) values (55,'M4785A08','honggd@naver.com','ys1234@naver.com','dadsdasdsadasdasdsa',to_date('22/08/17','RR/MM/DD'));
REM INSERTING into TMI_CHAT_ROOM
SET DEFINE OFF;
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('6etYO2E4','ym1234@naver.com','ys1234@naver.com',0,to_date('22/08/17','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('6Q0j1m1e','jdh1234@naver.com','ys1234@naver.com',0,to_date('22/08/17','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('E36S277u','ys1234@naver.com','ys1234@naver.com',0,to_date('22/08/17','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('M4785A08','ys1234@naver.com','honggd@naver.com',0,to_date('22/08/17','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('f9qxt1Pc','ym1234@naver.com','honggd@naver.com',0,to_date('22/08/16','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('dUBuOO19','admin@naver.com','honggd@naver.com',0,to_date('22/08/17','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CHATROOM_ID,SEND_EMAIL,RECEIVE_EMAIL,LAST_CHECK,CREATED_AT,DELETED_AT) values ('WizN3xSK','ys1234@naver.com','admin@naver.com',0,to_date('22/08/16','RR/MM/DD'),null);
REM INSERTING into TMI_FRIEND_BOARD
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (83,null,'honggd@naver.com','asd12',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (84,null,'honggd@naver.com','첨부파일 확인',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),2);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (85,null,'honggd@naver.com','첨부파일 확인 ',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (86,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (21,null,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (22,null,'ks1234@naver.com','테스트7',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (23,null,'ks1234@naver.com','테스트8',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (24,null,'ks1234@naver.com','테스트9',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (25,null,'ks1234@naver.com','테스트10',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (26,null,'ks1234@naver.com','테스트11',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (27,null,'ks1234@naver.com','테스트12',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (28,null,'ks1234@naver.com','테스트13',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (29,null,'ks1234@naver.com','테스트14',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (30,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (31,null,'ym1234@naver.com','테스트2',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (129,null,'honggd@naver.com',null,to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),2);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (33,null,'mj1234@naver.com','테스트4',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (34,null,'ic1234@naver.com','테스트5',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (35,null,'th1234@naver.com','테스트6',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (36,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (37,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (38,null,'ks1234@naver.com','테스트16',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (39,null,'ks1234@naver.com','테스트17',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (40,null,'ks1234@naver.com','테스트18',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (41,null,'ks1234@naver.com','테스트19',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (42,null,'ks1234@naver.com','테스트20',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (43,null,'ks1234@naver.com','테스트21',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (44,null,'ks1234@naver.com','테스트22',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (45,null,'ks1234@naver.com','테스트23',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (46,null,'ks1234@naver.com','테스트24',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (47,null,'ks1234@naver.com','테스트25',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (48,null,'ks1234@naver.com','테스트26',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (49,null,'ks1234@naver.com','테스트27',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (50,null,'ks1234@naver.com','테스트28',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (51,null,'ks1234@naver.com','테스트29',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (52,null,'ks1234@naver.com','테스트30',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (53,null,'ks1234@naver.com','테스트31',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (54,null,'ks1234@naver.com','테스트32',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (55,null,'ks1234@naver.com','테스트33',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (56,null,'ks1234@naver.com','테스트34',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (57,null,'ks1234@naver.com','테스트35',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (67,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (68,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (69,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (70,null,'ks1234@naver.com','가나다',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (71,null,'ks1234@naver.com','가나다asd',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (72,null,'ks1234@naver.com','가나다asdww',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (73,null,'honggd@naver.com','asdwww',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (107,null,'honggd@naver.com','asd',to_date('22/08/08','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),3);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (87,null,'honggd@naver.com','aasd',to_date('22/08/08','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (65,null,'ks1234@naver.com','테스트',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (66,null,'ks1234@naver.com','테스트22222',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (74,null,'honggd@naver.com','되라',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (75,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (76,null,'honggd@naver.com','이미지가 억까한다',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (77,null,'honggd@naver.com','asd',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (78,null,'honggd@naver.com','이미지 몇개',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (79,null,'honggd@naver.com','이미지 테스트',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (81,null,'honggd@naver.com','첨부파일 실험',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (139,null,'honggd@naver.com','aaa',to_date('22/08/10','RR/MM/DD'),to_date('22/08/10','RR/MM/DD'),8);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (143,null,'honggd@naver.com','asddddasdasddddds',to_date('22/08/10','RR/MM/DD'),to_date('22/08/10','RR/MM/DD'),10);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (167,null,'ys1234@naver.com','hi',to_date('22/08/16','RR/MM/DD'),to_date('22/08/16','RR/MM/DD'),4);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (208,305,'honggd@naver.com','asd',to_date('22/08/18','RR/MM/DD'),to_date('22/08/18','RR/MM/DD'),3);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (130,null,'honggd@naver.com','ㅁㅁㅁㅁ',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),2);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (131,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),3);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (132,null,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),3);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (145,null,'honggd@naver.com','한글 파일 실험',to_date('22/08/10','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),7);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (152,null,'honggd@naver.com','asd',to_date('22/08/15','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'),3);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (148,null,'honggd@naver.com','테스트ㅁㅁㅇㅇ',to_date('22/08/15','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'),3);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (153,null,'honggd@naver.com','asd',to_date('22/08/15','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'),6);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (154,null,'honggd@naver.com','asd',to_date('22/08/15','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'),6);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (134,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),3);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (135,null,'honggd@naver.com','게시판 테스트',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),6);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (146,null,'admin@naver.com','관리자',to_date('22/08/13','RR/MM/DD'),to_date('22/08/13','RR/MM/DD'),16);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (218,272,'ym1234@naver.com','플래너 테스트',to_date('22/08/18','RR/MM/DD'),to_date('22/08/18','RR/MM/DD'),2);
REM INSERTING into TMI_FRIEND_BOARD_ATTACHMENT
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (41,83,'fish.png','20220808_014937607_291.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (42,84,'dog.png','20220808_015012885_272.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (43,86,'dog.png','20220808_015956206_217.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (22,21,'test.jpg','20200525_090909_123.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (23,22,'moon.jpg','20200525_090909_345.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (24,23,'sun.jpg','20200525_020425_345.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (46,107,'fish.png','20220809_013708754_171.png',to_date('22/08/08','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (44,87,'cat.png','20220808_150146453_216.png',to_date('22/08/08','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (45,87,'dog.png','20220808_150146454_855.png',to_date('22/08/08','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (81,143,'cat.png','20220810_230022159_906.png',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (82,143,'fish.png','20220810_230022160_043.png',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (85,145,'fish.png','20220811_023256806_004.png',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (86,145,'수제비 실기 요약.docx.pdf','20220811_023256808_466.pdf',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (89,148,'fish (1).png','20220816_013452933_649.png',to_date('22/08/15','RR/MM/DD'));
REM INSERTING into TMI_FRIEND_BOARD_COMMENT
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (30,'honggd@naver.com',139,to_date('22/08/13','RR/MM/DD'),'테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (24,'honggd@naver.com',139,to_date('22/08/13','RR/MM/DD'),'테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (1,'honggd@naver.com',145,to_date('22/08/11','RR/MM/DD'),'댓글 테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (21,'honggd@naver.com',145,to_date('22/08/13','RR/MM/DD'),'테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (31,'honggd@naver.com',145,to_date('22/08/13','RR/MM/DD'),'댓글 테스트');
REM INSERTING into TMI_MEMBER
SET DEFINE OFF;
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (145,'danji@naver.com','뚱단지','$2a$10$gJ8gy68uQ8OkgfbamaMbFuvIZBFQK/gJ8R0ySzPWq5P0G2CpkgyQW','최단지','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (148,'bsj1234@naver.com','박서준','$2a$10$jbR85SR.Zov46aCDFyXzM.kFK97HCcTIqW9fpaIE52hA8Q/WAKzOO','박서준','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (150,'jdh1234@naver.com','헤이즈','$2a$10$aC5RhqHvROdxjDATaZ1sWuNc4zOa6pB/SigyLe8upUQwYeDdaPLki','장다혜','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (151,'ey1225@naver.com','벤','$2a$10$sHGQePjPn1OBpgvsxW8OueYH9rw9O7hBhB3ZqVA.JdTGDSSZlKvBC','이은영','01024243535',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (152,'ym123@naver.com','용민이','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','김용민','01000000000',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (71,'admin@naver.com','관리자','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','관리자','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (72,'ym1234@naver.com','김용민','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ym1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (73,'ks1234@naver.com','이경석','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ks1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (169,'susu@naver.com','수수해','$2a$10$glTEdNXuriwnGl0vYdzeke9DCfZwPHbudJpuPYwG7TQNp5nRhFwOy','김수수','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (75,'mj1234@naver.com','권민지','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','mj1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (76,'ic1234@naver.com','전인찬','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ic1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (77,'th1234@naver.com','안태현','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','th1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (78,'test1111@naver.com','테스트1','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','test1111','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (125,'TMI@gmail.com','이아엠티','$2a$10$NqyEATUKYfhm1Ny3Xe9QbOx3rwPE0vRsrjHbaGdLAr3UlP9EwELQa','티엠아이','01012349876',to_date('22/08/06','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (146,'dmin@naver.com','드드민','$2a$10$S0hwPdWyzhB13VmiXFynuugR5RMcvHfPt.S5NxMd7UfDWN9P2Zxom','이드민','01011112233',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (81,'honggd@naver.com','홍홍홍','$2a$10$EXTuRLRjK1z5DxbngxRhcOv74jtWGcspNLssI0sOvj2gGLs8a/OEO','홍길동','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (144,'munji@naver.com','냥펀치','$2a$10$FfpQpLtCgNR76oj4IF/MteY6NujD7u.Av/HGzDjoIqkvrbVEYIuQu','최먼지','01023234343',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (147,'tan1234@naver.com','탄왕자','$2a$10$7YBrrMRAEZFDsreQpMLyje1lAqkgkrQrYoKesS1PVz./N7a0oE/cq','최탄','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (149,'ml1234@naver.com','멜로망스','$2a$10$h90/YkQ5BKh/N8iPNeQ71.Izs0UH21U.0EUL5eDY/7TyIMCqxHIA.','김멜로','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (74,'ys1234@naver.com','최윤서','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ys1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (171,'bbob@naver.com','언니들','$2a$10$cioWla6xxJPodphV9x3EYursTl2JWToHt5lyC9joVGXtRQlpr0eu6','김밥맛','01098779877',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (172,'hb1234@naver.com','히밥','$2a$10$czi8ALh1GSp9gbOa7WJoUeD3HpXxAyaMm8KmbD4v5TMIVv6t2MgOu','김히밥','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (190,'ggy3381@naver.com','이방인','$2a$10$AQod//85GbV.2lPNMozH/OlikJfSfm2AxZI7BtKFZoXulF/0SYxeC','안태현','01076563381',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (170,'rjqnrdl@naver.com','꼬부기','$2a$10$cbQvotzgQ3Vv2INwOUaJXeamLiVTaIAdSsCxItGIVv8XC.lVVfyqa','김꼬북','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (173,'cat1234@naver.com','냥아치','$2a$10$4d.Lz8c8WDdOTwFHgaFM8OeRy0ZczRFFed7PfByUvW6QDYBp6zrfu','고먐미','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (175,'hari1234@naver.com','하리쨩','$2a$10$DGRdiHtg5/DH4N4d4DNLo.lBeae7FwixNUE08ERU4Gpg6TvLWb91W','임하리','01087487222',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (189,'dddks1234@naver.com','아무무','$2a$10$Yjbs/EevAX.JK6wpLJ7ONOdVvWEYtGfxrixrxKnoexxmb5VPqP83G','아무개','01054546223',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (174,'egg1234@naver.com','노른자','$2a$10$qkjiadYIIj/7PHqrsvufj.5uve069G8hCxJXo6AP3Cd3b1icJYE9u','김계란','01012345555',to_date('22/08/09','RR/MM/DD'));
REM INSERTING into TMI_MEMBER_ROLE
SET DEFINE OFF;
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_ADMIN','admin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','TMI@gmail.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','bbob@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','bsj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','cat1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','danji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','dddks1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','dmin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','egg1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ey1225@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ggy3381@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','hari1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','hb1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','honggd@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ic1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','jdh1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ks1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','mj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ml1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','munji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','rjqnrdl@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','susu@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','tan1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','test1111@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','th1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ym1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ym123@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ys1234@naver.com');
REM INSERTING into TMI_NOTICE_BOARD
SET DEFINE OFF;
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (20,'ym1234@naver.com','테스트1','test',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (31,'honggd@naver.com','테스트1','test',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (21,'munji@naver.com','테스트2','test',to_date('22/08/04','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (22,'tan1234@naver.com','테스트3','test',to_date('22/08/04','RR/MM/DD'),to_date('22/08/05','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (23,'hb1234@naver.com','테스트4','test',to_date('22/08/05','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (24,'ggy3381@naver.com','테스트5','test',to_date('22/08/05','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (25,'rjqnrdl@naver.com','테스트6','test',to_date('22/08/06','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (26,'bbob@naver.com','테스트7','test',to_date('22/08/07','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (27,'ml1234@naver.com','테스트8','test',to_date('22/08/08','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (28,'bsj1234@naver.com','테스트9','test',to_date('22/08/08','RR/MM/DD'),to_date('22/08/10','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (29,'dmin@naver.com','테스트10','test',to_date('22/08/09','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (30,'ys1234@naver.com','테스트11','test',to_date('22/08/09','RR/MM/DD'),to_date('22/08/12','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (152,'ym1234@naver.com','테스트1','test',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (144,'munji@naver.com','테스트2','test',to_date('22/08/04','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (147,'tan1234@naver.com','테스트3','test',to_date('22/08/04','RR/MM/DD'),to_date('22/08/05','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (172,'hb1234@naver.com','테스트4','test',to_date('22/08/05','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (74,'ys1234@naver.com','테스트5','test',to_date('22/08/05','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (171,'bbob@naver.com','테스트6','test',to_date('22/08/06','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (190,'ggy3381@naver.com','테스트7','test',to_date('22/08/07','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (173,'cat1234@naver.com','테스트8','test',to_date('22/08/08','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (175,'hari1234@naver.com','테스트9','test',to_date('22/08/08','RR/MM/DD'),to_date('22/08/10','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (189,'dddks1234@naver.com','테스트10','test',to_date('22/08/09','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),0);
Insert into TMI_NOTICE_BOARD (NB_NO,NB_M_EMAIL,NB_TITLE,NB_CONTENT,NB_CREATED_AT,NB_UPDATE_AT,NB_READ_COUNT) values (174,'egg1234@naver.com','테스트11','test',to_date('22/08/09','RR/MM/DD'),to_date('22/08/12','RR/MM/DD'),0);
REM INSERTING into TMI_NOTICE_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER
SET DEFINE OFF;
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (272,'ym1234@naver.com','테스트 일정',null,to_date('22/09/01','RR/MM/DD'),to_date('22/09/05','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'));
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (0,'admin@naver.com','0',null,to_date('22/08/18','RR/MM/DD'),to_date('22/08/18','RR/MM/DD'),null);
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (319,'ym1234@naver.com','test1','1',to_date('22/08/01','RR/MM/DD'),to_date('22/08/03','RR/MM/DD'),to_date('22/08/18','RR/MM/DD'));
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (320,'ym1234@naver.com','test2','1',to_date('22/08/10','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),to_date('22/08/18','RR/MM/DD'));
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE) values (305,'honggd@naver.com','asd','asd',to_date('22/08/17','RR/MM/DD'),to_date('22/08/19','RR/MM/DD'),to_date('22/08/17','RR/MM/DD'));
REM INSERTING into TMI_PLANNER_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_LOVE
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_PLAN
SET DEFINE OFF;
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (393,272,to_timestamp('70/01/01 14:00:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'KH정보교육원 강남지원 1관',null,'127.03285','37.498936',to_date('22/09/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (394,272,to_timestamp('70/01/01 15:40:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'CGV 강남',null,'127.02639','37.501656',to_date('22/09/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (395,272,to_timestamp('70/01/01 16:30:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'다이소 강남본점',null,'127.029045','37.49595',to_date('22/09/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (396,272,to_timestamp('70/01/01 15:10:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'신라스테이 역삼',null,'127.041306','37.504974',to_date('22/09/02','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (397,272,to_timestamp('70/01/01 14:05:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'영풍문고 강남역점',null,'127.02743','37.49916',to_date('22/09/02','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (398,272,to_timestamp('70/01/01 14:10:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'홍대입구역 2호선',null,'126.92378','37.55687',to_date('22/09/03','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (399,272,to_timestamp('70/01/01 23:10:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'CGV 홍대',null,'126.92262','37.556503',to_date('22/09/03','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (400,272,to_timestamp('70/01/01 14:05:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'홍대패션거리',null,'126.923584','37.555397',to_date('22/09/04','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (477,319,null,'울산KH정보교육원',null,'129.3108','35.535015',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (478,319,null,'울산KH정보교육원',null,'129.3108','35.535015',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (479,319,null,'KH정보교육원 강남지원 1관',null,'127.03285','37.498936',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (480,319,null,'KH정보교육원 강남지원 1관',null,'127.03285','37.498936',to_date('22/08/01','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (457,305,null,'울산KH정보교육원',null,'129.3108','35.535015',to_date('22/08/17','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (458,305,null,'KH정보교육원 강남지원 1관',null,'127.03285','37.498936',to_date('22/08/18','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (481,320,null,'울산KH정보교육원',null,'129.3108','35.535015',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (482,320,null,'울산KH정보교육원',null,'129.3108','35.535015',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (483,320,null,'KH정보교육원 당산지원',null,'126.89676','37.53391',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (484,320,null,'KH정보교육원 당산지원',null,'126.89676','37.53391',to_date('22/08/10','RR/MM/DD'));
REM INSERTING into TMI_REVIEW_BOARD
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (21,null,'honggd@naver.com','썸네일 테스트1',to_date('22/08/15','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'),1);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (1,null,'ks1234@naver.com','테스트1',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (2,null,'ys1234@naver.com','테스트2',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (3,null,'mj1234@naver.com','테스트3',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (4,null,'ym1234@naver.com','테스트4',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (5,null,'th1234@naver.com','테스트5',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (6,null,'ic1234@naver.com','테스트6',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (7,null,'ks1234@naver.com','테스트7',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),2);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (8,null,'ks1234@naver.com','테스트8',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),2);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (9,null,'ks1234@naver.com','테스트9',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),2);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (10,null,'ks1234@naver.com','테스트10',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),2);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (11,null,'ks1234@naver.com','테스트11',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),2);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (23,null,'honggd@naver.com','썸네일 테스트2',to_date('22/08/15','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'),3);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (24,null,'honggd@naver.com','썸네일 테스트3',to_date('22/08/15','RR/MM/DD'),to_date('22/08/15','RR/MM/DD'),2);
REM INSERTING into TMI_REVIEW_BOARD_ATTACHMENT
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (1,11,'test.jpg','20200525_090909_123.jpg',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (2,10,'moon.jpg','20200525_090909_345.jpg',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (3,9,'sun.jpg','20200525_020425_345.jpg',to_date('22/08/14','RR/MM/DD'));
REM INSERTING into TMI_REVIEW_BOARD_COMMENT
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD_COMMENT (RBC_NO,RBC_RB_NO,RBC_M_EMAIL,RBC_CREATED_AT,RBC_CONTENT) values (3,11,'honggd@naver.com',to_date('22/08/14','RR/MM/DD'),'댓글 테스트');
Insert into TMI_REVIEW_BOARD_COMMENT (RBC_NO,RBC_RB_NO,RBC_M_EMAIL,RBC_CREATED_AT,RBC_CONTENT) values (4,10,'admin@naver.com',to_date('22/08/14','RR/MM/DD'),'댓글 테스트2');
REM INSERTING into TMI_REVIEW_BOARD_LOVE
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (1,9,'honggd@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (2,9,'admin@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (6,10,'honggd@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (23,9,'ks1234@naver.com',1);
Insert into TMI_REVIEW_BOARD_LOVE (RBL_NO,RBL_RB_NO,RBL_M_EMAIL,RBL_TYPE) values (22,7,'honggd@naver.com',1);
--------------------------------------------------------
--  DDL for Index SYS_C0042334
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0042334" ON "PERSISTENT_LOGINS" ("SERIES")
--------------------------------------------------------
--  DDL for Index PK_CHAT_CONTENT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CHAT_CONTENT" ON "TMI_CHAT_CONTENT" ("CONTENT_NO")
--------------------------------------------------------
--  DDL for Index PK_CHAT_ROOM
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CHAT_ROOM" ON "TMI_CHAT_ROOM" ("CHATROOM_ID")
--------------------------------------------------------
--  DDL for Index PK_FB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FB_NO" ON "TMI_FRIEND_BOARD" ("FB_NO")
--------------------------------------------------------
--  DDL for Index PK_FBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBA_NO" ON "TMI_FRIEND_BOARD_ATTACHMENT" ("FBA_NO")
--------------------------------------------------------
--  DDL for Index PK_FBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBC_NO" ON "TMI_FRIEND_BOARD_COMMENT" ("FBC_NO")
--------------------------------------------------------
--  DDL for Index PK_M_EMAIL
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_M_EMAIL" ON "TMI_MEMBER" ("M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_MR_AUTH
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MR_AUTH" ON "TMI_MEMBER_ROLE" ("MR_AUTH", "MR_M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_NB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NB_NO" ON "TMI_NOTICE_BOARD" ("NB_NO")
--------------------------------------------------------
--  DDL for Index PK_NBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NBA_NO" ON "TMI_NOTICE_BOARD_ATTACHMENT" ("NBA_NO")
--------------------------------------------------------
--  DDL for Index PK_P_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_P_NO" ON "TMI_PLANNER" ("P_NO")
--------------------------------------------------------
--  DDL for Index PK_PB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PB_NO" ON "TMI_PLANNER_BOARD" ("PB_NO")
--------------------------------------------------------
--  DDL for Index PK_PBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBC_NO" ON "TMI_PLANNER_BOARD_COMMENT" ("PBC_NO")
--------------------------------------------------------
--  DDL for Index PK_PBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBL_LOVE_NO" ON "TMI_PLANNER_BOARD_LOVE" ("PBL_LOVE_NO")
--------------------------------------------------------
--  DDL for Index PK_PP_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PP_NO" ON "TMI_PLANNER_PLAN" ("PP_NO")
--------------------------------------------------------
--  DDL for Index PK_RB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RB_NO" ON "TMI_REVIEW_BOARD" ("RB_NO")
--------------------------------------------------------
--  DDL for Index PK_RBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBA_NO" ON "TMI_REVIEW_BOARD_ATTACHMENT" ("RBA_NO")
--------------------------------------------------------
--  DDL for Index PK_RBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBC_NO" ON "TMI_REVIEW_BOARD_COMMENT" ("RBC_NO")
--------------------------------------------------------
--  DDL for Index PK_RBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBL_LOVE_NO" ON "TMI_REVIEW_BOARD_LOVE" ("RBL_NO")
--------------------------------------------------------
--  Constraints for Table PERSISTENT_LOGINS
--------------------------------------------------------

  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("USERNAME" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("TOKEN" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("LAST_USED" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" ADD PRIMARY KEY ("SERIES")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("CONTENT_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("CHATROOM_ID" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("SEND_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("RECEIVE_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "PK_CHAT_CONTENT" PRIMARY KEY ("CONTENT_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CHATROOM_ID" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("SEND_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("RECEIVE_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "PK_CHAT_ROOM" PRIMARY KEY ("CHATROOM_ID")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" MODIFY ("FB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "PK_FB_NO" PRIMARY KEY ("FB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_FBA_NO" PRIMARY KEY ("FBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" MODIFY ("FBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "PK_FBC_NO" PRIMARY KEY ("FBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PASSWORD" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PHONE" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" ADD CONSTRAINT "PK_M_EMAIL" PRIMARY KEY ("M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" MODIFY ("MR_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "PK_MR_AUTH" PRIMARY KEY ("MR_AUTH", "MR_M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" MODIFY ("NB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "PK_NB_NO" PRIMARY KEY ("NB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_NBA_NO" PRIMARY KEY ("NBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" MODIFY ("P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_TITLE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_LEAVE_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_RETURN_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "PK_P_NO" PRIMARY KEY ("P_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "PK_PB_NO" PRIMARY KEY ("PB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" MODIFY ("PBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "PK_PBC_NO" PRIMARY KEY ("PBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_LOVE_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "PK_PBL_LOVE_NO" PRIMARY KEY ("PBL_LOVE_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_X" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_Y" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "PK_PP_NO" PRIMARY KEY ("PP_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" MODIFY ("RB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "PK_RB_NO" PRIMARY KEY ("RB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_RBA_NO" PRIMARY KEY ("RBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" MODIFY ("RBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "PK_RBC_NO" PRIMARY KEY ("RBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "PK_RBL_LOVE_NO" PRIMARY KEY ("RBL_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "FK_CHAT_CONTENT_CHATROOM_ID" FOREIGN KEY ("CHATROOM_ID")
	  REFERENCES "TMI_CHAT_ROOM" ("CHATROOM_ID") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_SEND_EMAIL" FOREIGN KEY ("SEND_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_RECEIVE_EMAIL" FOREIGN KEY ("RECEIVE_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_P_NO" FOREIGN KEY ("FB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_M_EMAIL" FOREIGN KEY ("FB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_FB_NO" FOREIGN KEY ("FBA_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_COMENT_RB_NO" FOREIGN KEY ("FBC_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_M_EMAIL" FOREIGN KEY ("FBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "FK_MEMBER_ROLE_M_EMAIL" FOREIGN KEY ("MR_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "FK_NOTICE_BOARD_M_EMAIL" FOREIGN KEY ("NB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_NB_NO" FOREIGN KEY ("NBA_NB_NO")
	  REFERENCES "TMI_NOTICE_BOARD" ("NB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "FK_PLANNER_M_EMAIL" FOREIGN KEY ("P_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_P_NO" FOREIGN KEY ("PB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_M_EMAIL" FOREIGN KEY ("PB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_PB_NO" FOREIGN KEY ("PBC_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_M_EMAIL" FOREIGN KEY ("PBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_PB_NO" FOREIGN KEY ("PBL_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("PBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "FK_PLANNER_PLAN_P_NO" FOREIGN KEY ("PP_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_P_NO" FOREIGN KEY ("RB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_M_EMAIL" FOREIGN KEY ("RB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_REVIEW_BOARD_ATTACHMENT_RB_NO" FOREIGN KEY ("RBA_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_COMENT_RB_NO" FOREIGN KEY ("RBC_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_M_EMAIL" FOREIGN KEY ("RBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_RB_NO" FOREIGN KEY ("RBL_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("RBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
