--------------------------------------------------------
--  파일이 생성됨 - 월요일-8월-15-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PERSISTENT_LOGINS
--------------------------------------------------------

  CREATE TABLE "PERSISTENT_LOGINS" 
   (	"USERNAME" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"SERIES" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"TOKEN" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"LAST_USED" TIMESTAMP (6)
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_CONTENT" 
   (	"CC_NO" NUMBER, 
	"CC_CR_ID" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"CC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"CC_MESSAGE" VARCHAR2(4000) COLLATE "USING_NLS_COMP", 
	"CC_TIME" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_ROOM
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_ROOM" 
   (	"CR_ID" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"CR_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"CR_LAST_CHECK" NUMBER DEFAULT 0, 
	"CR_CREATED_AT" DATE DEFAULT sysdate, 
	"CR_DELETED_AT" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD" 
   (	"FB_NO" NUMBER, 
	"FB_P_NO" NUMBER, 
	"FB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_TITLE" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_CREATED_AT" DATE DEFAULT sysdate, 
	"FB_UPDATED_AT" DATE DEFAULT sysdate, 
	"FB_READ_COUNT" NUMBER DEFAULT 0, 
	"FB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_ATTACHMENT" 
   (	"FBA_NO" NUMBER, 
	"FBA_FB_NO" NUMBER, 
	"FBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"TBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_COMMENT" 
   (	"FBC_NO" NUMBER, 
	"FBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBC_FB_NO" NUMBER, 
	"FBC_CREATED_AT" DATE DEFAULT sysdate, 
	"FBC_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER" 
   (	"M_NO" NUMBER, 
	"M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PASSWORD" VARCHAR2(512) COLLATE "USING_NLS_COMP", 
	"M_NAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PHONE" CHAR(11) COLLATE "USING_NLS_COMP", 
	"M_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER_ROLE" 
   (	"MR_AUTH" VARCHAR2(20) COLLATE "USING_NLS_COMP", 
	"MR_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD" 
   (	"NB_NO" NUMBER, 
	"NB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"NB_CREATED_AT" DATE DEFAULT sysdate, 
	"NB_UPDATE_AT" DATE DEFAULT sysdate, 
	"NB_READ_COUNT" NUMBER DEFAULT 0, 
	"NB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD_ATTACHMENT" 
   (	"NBA_NO" NUMBER, 
	"NBA_NB_NO" NUMBER, 
	"NBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER" 
   (	"P_NO" NUMBER, 
	"P_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"P_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_EXPLAN" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_LEAVE_DATE" DATE, 
	"P_RETURN_DATE" DATE, 
	"P_WRITE_DATE" DATE DEFAULT sysdate, 
	"P_SHARE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT 'N'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD" 
   (	"PB_NO" NUMBER, 
	"PB_P_NO" NUMBER, 
	"PB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PB_CREATED_AT" DATE DEFAULT sysdate, 
	"PB_UPDATED_AT" DATE DEFAULT sysdate, 
	"PB_READ_COUNT" NUMBER DEFAULT 0, 
	"PB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_COMMENT" 
   (	"PBC_NO" NUMBER, 
	"PBC_PB_NO" NUMBER, 
	"PBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBC_CREATED_AT" DATE DEFAULT sysdate, 
	"PBC_CONTENT" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_LOVE" 
   (	"PBL_LOVE_NO" NUMBER, 
	"PBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBL_PB_NO" NUMBER, 
	"PBL_LOVETYPE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT '0'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_PLAN" 
   (	"PP_NO" NUMBER, 
	"PP_P_NO" NUMBER, 
	"PP_TIME" TIMESTAMP (6), 
	"PP_PLACE_NAME" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PP_MEMO" VARCHAR2(2000) COLLATE "USING_NLS_COMP" DEFAULT null, 
	"PP_X" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PP_Y" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PP_DATE" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD" 
   (	"RB_NO" NUMBER, 
	"RB_P_NO" NUMBER, 
	"RB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"RB_CREATED_AT" DATE DEFAULT sysdate, 
	"RB_UPDATED_AT" DATE DEFAULT sysdate, 
	"RB_READ_COUNT" NUMBER DEFAULT 0, 
	"RB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_ATTACHMENT" 
   (	"RBA_NO" NUMBER, 
	"RBA_RB_NO" NUMBER, 
	"RBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_COMMENT" 
   (	"RBC_NO" NUMBER, 
	"RBC_RB_NO" NUMBER, 
	"RBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_COMMENT_CREATE_AT" DATE DEFAULT sysdate, 
	"RB_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_LOVE" 
   (	"RBL_LOVE_NO" NUMBER, 
	"RBL_RB_NO" NUMBER, 
	"RBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBL_LOVETYPE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
REM INSERTING into PERSISTENT_LOGINS
SET DEFINE OFF;
REM INSERTING into TMI_CHAT_CONTENT
SET DEFINE OFF;
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (6,'9499fE01','ys1234@naver.com','ffff',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (7,'9499fE01','ys1234@naver.com','반가워요',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (8,'9499fE01','ys1234@naver.com','ㅎㅎㅎㅎ',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (9,'9499fE01','ys1234@naver.com','ㅎㅎㅎ',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (10,'9499fE01','ys1234@naver.com','ㄴㅇㄴㅇㄴㅇㄴ',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (11,'9499fE01','ys1234@naver.com','ㅎㅎㅎㅎ',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (12,'9499fE01','ys1234@naver.com','ggggg',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (13,'9499fE01','ys1234@naver.com','dzdzdzdzdz',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (14,'9499fE01','ys1234@naver.com','zzzzzz',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (15,'9499fE01','ys1234@naver.com','dsdssds',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (16,'9499fE01','ys1234@naver.com','123123123123132123',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (17,'9499fE01','ys1234@naver.com','zzzzzdzdz',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (18,'9499fE01','ys1234@naver.com','dffsdssdsds',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_CHAT_CONTENT (CC_NO,CC_CR_ID,CC_M_EMAIL,CC_MESSAGE,CC_TIME) values (19,'9499fE01','ys1234@naver.com','zdzdzzdz',to_date('22/08/14','RR/MM/DD'));
REM INSERTING into TMI_CHAT_ROOM
SET DEFINE OFF;
Insert into TMI_CHAT_ROOM (CR_ID,CR_M_EMAIL,CR_LAST_CHECK,CR_CREATED_AT,CR_DELETED_AT) values ('9499fE01','ys1234@naver.com',0,to_date('22/08/14','RR/MM/DD'),null);
Insert into TMI_CHAT_ROOM (CR_ID,CR_M_EMAIL,CR_LAST_CHECK,CR_CREATED_AT,CR_DELETED_AT) values ('9499fE01','admin@naver.com',0,to_date('22/08/14','RR/MM/DD'),null);
REM INSERTING into TMI_FRIEND_BOARD
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (82,null,'honggd@naver.com','asd',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (83,null,'honggd@naver.com','asd12',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (84,null,'honggd@naver.com','첨부파일 확인',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),2);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (85,null,'honggd@naver.com','첨부파일 확인 ',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (86,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (21,null,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (22,null,'ks1234@naver.com','테스트7',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (23,null,'ks1234@naver.com','테스트8',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (24,null,'ks1234@naver.com','테스트9',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (25,null,'ks1234@naver.com','테스트10',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (26,null,'ks1234@naver.com','테스트11',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (27,null,'ks1234@naver.com','테스트12',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (28,null,'ks1234@naver.com','테스트13',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (29,null,'ks1234@naver.com','테스트14',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (30,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (31,null,'ym1234@naver.com','테스트2',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (129,null,'honggd@naver.com',null,to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (33,null,'mj1234@naver.com','테스트4',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (34,null,'ic1234@naver.com','테스트5',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (35,null,'th1234@naver.com','테스트6',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (36,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (37,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (38,null,'ks1234@naver.com','테스트16',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (39,null,'ks1234@naver.com','테스트17',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (40,null,'ks1234@naver.com','테스트18',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (41,null,'ks1234@naver.com','테스트19',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (42,null,'ks1234@naver.com','테스트20',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (43,null,'ks1234@naver.com','테스트21',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (44,null,'ks1234@naver.com','테스트22',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (45,null,'ks1234@naver.com','테스트23',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (46,null,'ks1234@naver.com','테스트24',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (47,null,'ks1234@naver.com','테스트25',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (48,null,'ks1234@naver.com','테스트26',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (49,null,'ks1234@naver.com','테스트27',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (50,null,'ks1234@naver.com','테스트28',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (51,null,'ks1234@naver.com','테스트29',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (52,null,'ks1234@naver.com','테스트30',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (53,null,'ks1234@naver.com','테스트31',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (54,null,'ks1234@naver.com','테스트32',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (55,null,'ks1234@naver.com','테스트33',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (56,null,'ks1234@naver.com','테스트34',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (57,null,'ks1234@naver.com','테스트35',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (67,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (68,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (69,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (70,null,'ks1234@naver.com','가나다',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (71,null,'ks1234@naver.com','가나다asd',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (72,null,'ks1234@naver.com','가나다asdww',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (73,null,'honggd@naver.com','asdwww',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (107,null,'honggd@naver.com','asd',to_date('22/08/08','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),2);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (87,null,'honggd@naver.com','aasd',to_date('22/08/08','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (65,null,'ks1234@naver.com','테스트',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (66,null,'ks1234@naver.com','테스트22222',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (74,null,'honggd@naver.com','되라',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (75,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (76,null,'honggd@naver.com','이미지가 억까한다',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (77,null,'honggd@naver.com','asd',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (78,null,'honggd@naver.com','이미지 몇개',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (79,null,'honggd@naver.com','이미지 테스트',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (81,null,'honggd@naver.com','첨부파일 실험',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (139,null,'honggd@naver.com','aaa',to_date('22/08/10','RR/MM/DD'),to_date('22/08/10','RR/MM/DD'),8);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (143,null,'honggd@naver.com','asddddasdasddddds',to_date('22/08/10','RR/MM/DD'),to_date('22/08/10','RR/MM/DD'),9);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (130,null,'honggd@naver.com','ㅁㅁㅁㅁ',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (131,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (132,null,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),1);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (145,null,'honggd@naver.com','한글 파일 실험',to_date('22/08/10','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),7);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (134,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),2);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (135,null,'honggd@naver.com','게시판 테스트',to_date('22/08/09','RR/MM/DD'),to_date('22/08/09','RR/MM/DD'),4);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (146,null,'admin@naver.com','관리자',to_date('22/08/13','RR/MM/DD'),to_date('22/08/13','RR/MM/DD'),13);
REM INSERTING into TMI_FRIEND_BOARD_ATTACHMENT
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (41,83,'fish.png','20220808_014937607_291.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (42,84,'dog.png','20220808_015012885_272.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (43,86,'dog.png','20220808_015956206_217.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (22,21,'test.jpg','20200525_090909_123.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (23,22,'moon.jpg','20200525_090909_345.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (24,23,'sun.jpg','20200525_020425_345.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (46,107,'fish.png','20220809_013708754_171.png',to_date('22/08/08','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (44,87,'cat.png','20220808_150146453_216.png',to_date('22/08/08','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (45,87,'dog.png','20220808_150146454_855.png',to_date('22/08/08','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (81,143,'cat.png','20220810_230022159_906.png',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (82,143,'fish.png','20220810_230022160_043.png',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (85,145,'fish.png','20220811_023256806_004.png',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (86,145,'수제비 실기 요약.docx.pdf','20220811_023256808_466.pdf',to_date('22/08/10','RR/MM/DD'));
REM INSERTING into TMI_FRIEND_BOARD_COMMENT
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (30,'honggd@naver.com',139,to_date('22/08/13','RR/MM/DD'),'테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (24,'honggd@naver.com',139,to_date('22/08/13','RR/MM/DD'),'테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (1,'honggd@naver.com',145,to_date('22/08/11','RR/MM/DD'),'댓글 테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (21,'honggd@naver.com',145,to_date('22/08/13','RR/MM/DD'),'테스트');
Insert into TMI_FRIEND_BOARD_COMMENT (FBC_NO,FBC_M_EMAIL,FBC_FB_NO,FBC_CREATED_AT,FBC_CONTENT) values (31,'honggd@naver.com',145,to_date('22/08/13','RR/MM/DD'),'댓글 테스트');
REM INSERTING into TMI_MEMBER
SET DEFINE OFF;
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (103,'ddp3381@naver.com','싱코페이션','$2a$10$EyZJFtlw83ak12CMzTR0h.awMe21lq00rCp9N5VX3reJ4RVAtFXZS','안태현','01076563381',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (145,'danji@naver.com','뚱단지','$2a$10$gJ8gy68uQ8OkgfbamaMbFuvIZBFQK/gJ8R0ySzPWq5P0G2CpkgyQW','최단지','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (101,'ggy3381@naver.com','이방인','$2a$10$1AMYvftCUfP6UQVfikhVtODvHanH0sH9Rk.cPQ4mETFCLXsfyvtxS','안태현','01076563381',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (148,'bsj1234@naver.com','박서준','$2a$10$jbR85SR.Zov46aCDFyXzM.kFK97HCcTIqW9fpaIE52hA8Q/WAKzOO','박서준','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (150,'jdh1234@naver.com','헤이즈','$2a$10$aC5RhqHvROdxjDATaZ1sWuNc4zOa6pB/SigyLe8upUQwYeDdaPLki','장다혜','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (151,'ey1225@naver.com','벤','$2a$10$sHGQePjPn1OBpgvsxW8OueYH9rw9O7hBhB3ZqVA.JdTGDSSZlKvBC','이은영','01024243535',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (152,'ym123@naver.com','용민이','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','김용민','01000000000',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (71,'admin@naver.com','관리자','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','관리자','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (72,'ym1234@naver.com','김용민','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ym1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (73,'ks1234@naver.com','이경석','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ks1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (169,'susu@naver.com','수수해','$2a$10$glTEdNXuriwnGl0vYdzeke9DCfZwPHbudJpuPYwG7TQNp5nRhFwOy','김수수','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (75,'mj1234@naver.com','권민지','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','mj1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (76,'ic1234@naver.com','전인찬','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ic1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (77,'th1234@naver.com','안태현','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','th1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (78,'test1111@naver.com','테스트1','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','test1111','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (125,'TMI@gmail.com','이아엠티','$2a$10$NqyEATUKYfhm1Ny3Xe9QbOx3rwPE0vRsrjHbaGdLAr3UlP9EwELQa','티엠아이','01012349876',to_date('22/08/06','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (146,'dmin@naver.com','드드민','$2a$10$S0hwPdWyzhB13VmiXFynuugR5RMcvHfPt.S5NxMd7UfDWN9P2Zxom','이드민','01011112233',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (81,'honggd@naver.com','홍홍홍','$2a$10$EXTuRLRjK1z5DxbngxRhcOv74jtWGcspNLssI0sOvj2gGLs8a/OEO','홍길동','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (144,'munji@naver.com','냥펀치','$2a$10$FfpQpLtCgNR76oj4IF/MteY6NujD7u.Av/HGzDjoIqkvrbVEYIuQu','최먼지','01023234343',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (147,'tan1234@naver.com','탄왕자','$2a$10$7YBrrMRAEZFDsreQpMLyje1lAqkgkrQrYoKesS1PVz./N7a0oE/cq','최탄','01012341234',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (149,'ml1234@naver.com','멜로망스','$2a$10$h90/YkQ5BKh/N8iPNeQ71.Izs0UH21U.0EUL5eDY/7TyIMCqxHIA.','김멜로','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (74,'ys1234@naver.com','최윤서','$2a$10$NpcQaEykrJPgVEJruCCWxu3AGZEWo.jLHMwiSvZdsNILDYbGdUbIa','ys1234','01000000000',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (171,'bbob@naver.com','언니들','$2a$10$cioWla6xxJPodphV9x3EYursTl2JWToHt5lyC9joVGXtRQlpr0eu6','김밥맛','01098779877',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (172,'hb1234@naver.com','히밥','$2a$10$czi8ALh1GSp9gbOa7WJoUeD3HpXxAyaMm8KmbD4v5TMIVv6t2MgOu','김히밥','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (170,'rjqnrdl@naver.com','꼬부기','$2a$10$cbQvotzgQ3Vv2INwOUaJXeamLiVTaIAdSsCxItGIVv8XC.lVVfyqa','김꼬북','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (173,'cat1234@naver.com','냥아치','$2a$10$4d.Lz8c8WDdOTwFHgaFM8OeRy0ZczRFFed7PfByUvW6QDYBp6zrfu','고먐미','01012341234',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (175,'hari1234@naver.com','하리쨩','$2a$10$DGRdiHtg5/DH4N4d4DNLo.lBeae7FwixNUE08ERU4Gpg6TvLWb91W','임하리','01087487222',to_date('22/08/09','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (189,'dddks1234@naver.com','아무무','$2a$10$Yjbs/EevAX.JK6wpLJ7ONOdVvWEYtGfxrixrxKnoexxmb5VPqP83G','아무개','01054546223',to_date('22/08/10','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_CREATED_AT) values (174,'egg1234@naver.com','노른자','$2a$10$qkjiadYIIj/7PHqrsvufj.5uve069G8hCxJXo6AP3Cd3b1icJYE9u','김계란','01012345555',to_date('22/08/09','RR/MM/DD'));
REM INSERTING into TMI_MEMBER_ROLE
SET DEFINE OFF;
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_ADMIN','admin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','TMI@gmail.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','bbob@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','bsj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','cat1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','danji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','dddks1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ddp3381@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','dmin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','egg1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ey1225@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ggy3381@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','hari1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','hb1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','honggd@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ic1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','jdh1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ks1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','mj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ml1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','munji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','rjqnrdl@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','susu@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','tan1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','test1111@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','th1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ym1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ym123@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ys1234@naver.com');
REM INSERTING into TMI_NOTICE_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_NOTICE_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER
SET DEFINE OFF;
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE,P_SHARE) values (257,'ym1234@naver.com','홍대 나들이','홍대로 놀러가봐요',to_date('22/08/14','RR/MM/DD'),to_date('22/08/16','RR/MM/DD'),to_date('22/08/13','RR/MM/DD'),'N');
REM INSERTING into TMI_PLANNER_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_LOVE
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_PLAN
SET DEFINE OFF;
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (370,257,to_timestamp('70/01/01 12:20:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'홍대입구역 2호선','지하철 타고 슝슝','126.92378','37.55687',to_date('22/08/13','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (371,257,to_timestamp('70/01/01 13:00:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'라멘무메이','김용민 단골 라멘집.','126.92289','37.558853',to_date('22/08/13','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (372,257,to_timestamp('70/01/01 15:00:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'CGV 연남','탑건 보기','126.925896','37.557667',to_date('22/08/13','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (373,257,to_timestamp('70/01/01 17:20:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'스타벅스 홍대역점','커피는 국룰','126.92364','37.55729',to_date('22/08/13','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (374,257,to_timestamp('70/01/01 14:20:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'망리단길','막상 가보면 별거 없는 망리단길','126.905914','37.553658',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (375,257,to_timestamp('70/01/01 15:15:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'소금집델리 망원','잠봉뵈르 나는 맛 없던데','126.90823','37.556824',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_PLANNER_PLAN (PP_NO,PP_P_NO,PP_TIME,PP_PLACE_NAME,PP_MEMO,PP_X,PP_Y,PP_DATE) values (376,257,to_timestamp('70/01/01 12:15:00.000000000','RR/MM/DD HH24:MI:SSXFF'),'크레이지카츠','여기 돈까스 JMTGR','126.909706','37.55045',to_date('22/08/15','RR/MM/DD'));
REM INSERTING into TMI_REVIEW_BOARD
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (1,null,'ks1234@naver.com','테스트1',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (2,null,'ys1234@naver.com','테스트2',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (3,null,'mj1234@naver.com','테스트3',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (4,null,'ym1234@naver.com','테스트4',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (5,null,'th1234@naver.com','테스트5',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (6,null,'ic1234@naver.com','테스트6',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (7,null,'ks1234@naver.com','테스트7',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (8,null,'ks1234@naver.com','테스트8',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (9,null,'ks1234@naver.com','테스트9',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (10,null,'ks1234@naver.com','테스트10',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_REVIEW_BOARD (RB_NO,RB_P_NO,RB_M_EMAIL,RB_TITLE,RB_CREATED_AT,RB_UPDATED_AT,RB_READ_COUNT) values (11,null,'ks1234@naver.com','테스트11',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
REM INSERTING into TMI_REVIEW_BOARD_ATTACHMENT
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (1,11,'test.jpg','20200525_090909_123.jpg',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (2,10,'moon.jpg','20200525_090909_345.jpg',to_date('22/08/14','RR/MM/DD'));
Insert into TMI_REVIEW_BOARD_ATTACHMENT (RBA_NO,RBA_RB_NO,RBA_ORIGINAL_FILENAME,RBA_RENAMED_FILENAME,RBA_CREATED_AT) values (3,9,'sun.jpg','20200525_020425_345.jpg',to_date('22/08/14','RR/MM/DD'));
REM INSERTING into TMI_REVIEW_BOARD_COMMENT
SET DEFINE OFF;
Insert into TMI_REVIEW_BOARD_COMMENT (RBC_NO,RBC_RB_NO,RBC_M_EMAIL,RB_COMMENT_CREATE_AT,RB_CONTENT) values (3,11,'honggd@naver.com',to_date('22/08/14','RR/MM/DD'),'댓글 테스트');
Insert into TMI_REVIEW_BOARD_COMMENT (RBC_NO,RBC_RB_NO,RBC_M_EMAIL,RB_COMMENT_CREATE_AT,RB_CONTENT) values (4,10,'admin@naver.com',to_date('22/08/14','RR/MM/DD'),'댓글 테스트2');
REM INSERTING into TMI_REVIEW_BOARD_LOVE
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C0042334
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0042334" ON "PERSISTENT_LOGINS" ("SERIES")
--------------------------------------------------------
--  DDL for Index PK_CC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CC_NO" ON "TMI_CHAT_CONTENT" ("CC_NO")
--------------------------------------------------------
--  DDL for Index PK_CHAT_MEMBER
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CHAT_MEMBER" ON "TMI_CHAT_ROOM" ("CR_ID", "CR_M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_FB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FB_NO" ON "TMI_FRIEND_BOARD" ("FB_NO")
--------------------------------------------------------
--  DDL for Index PK_FBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBA_NO" ON "TMI_FRIEND_BOARD_ATTACHMENT" ("FBA_NO")
--------------------------------------------------------
--  DDL for Index PK_FBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBC_NO" ON "TMI_FRIEND_BOARD_COMMENT" ("FBC_NO")
--------------------------------------------------------
--  DDL for Index PK_M_EMAIL
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_M_EMAIL" ON "TMI_MEMBER" ("M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_MR_AUTH
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MR_AUTH" ON "TMI_MEMBER_ROLE" ("MR_AUTH", "MR_M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_NB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NB_NO" ON "TMI_NOTICE_BOARD" ("NB_NO")
--------------------------------------------------------
--  DDL for Index PK_NBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NBA_NO" ON "TMI_NOTICE_BOARD_ATTACHMENT" ("NBA_NO")
--------------------------------------------------------
--  DDL for Index PK_P_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_P_NO" ON "TMI_PLANNER" ("P_NO")
--------------------------------------------------------
--  DDL for Index PK_PB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PB_NO" ON "TMI_PLANNER_BOARD" ("PB_NO")
--------------------------------------------------------
--  DDL for Index PK_PBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBC_NO" ON "TMI_PLANNER_BOARD_COMMENT" ("PBC_NO")
--------------------------------------------------------
--  DDL for Index PK_PBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBL_LOVE_NO" ON "TMI_PLANNER_BOARD_LOVE" ("PBL_LOVE_NO")
--------------------------------------------------------
--  DDL for Index PK_PP_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PP_NO" ON "TMI_PLANNER_PLAN" ("PP_NO")
--------------------------------------------------------
--  DDL for Index PK_RB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RB_NO" ON "TMI_REVIEW_BOARD" ("RB_NO")
--------------------------------------------------------
--  DDL for Index PK_RBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBA_NO" ON "TMI_REVIEW_BOARD_ATTACHMENT" ("RBA_NO")
--------------------------------------------------------
--  DDL for Index PK_RBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBC_NO" ON "TMI_REVIEW_BOARD_COMMENT" ("RBC_NO")
--------------------------------------------------------
--  DDL for Index PK_RBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBL_LOVE_NO" ON "TMI_REVIEW_BOARD_LOVE" ("RBL_LOVE_NO")
--------------------------------------------------------
--  Constraints for Table PERSISTENT_LOGINS
--------------------------------------------------------

  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("USERNAME" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("TOKEN" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("LAST_USED" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" ADD PRIMARY KEY ("SERIES")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("CC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "PK_CC_NO" PRIMARY KEY ("CC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CR_ID" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CR_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "PK_CHAT_MEMBER" PRIMARY KEY ("CR_ID", "CR_M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" MODIFY ("FB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "PK_FB_NO" PRIMARY KEY ("FB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_FBA_NO" PRIMARY KEY ("FBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" MODIFY ("FBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "PK_FBC_NO" PRIMARY KEY ("FBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PASSWORD" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PHONE" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" ADD CONSTRAINT "PK_M_EMAIL" PRIMARY KEY ("M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" MODIFY ("MR_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "PK_MR_AUTH" PRIMARY KEY ("MR_AUTH", "MR_M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" MODIFY ("NB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "PK_NB_NO" PRIMARY KEY ("NB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_NBA_NO" PRIMARY KEY ("NBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" MODIFY ("P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_TITLE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_LEAVE_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_RETURN_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "PK_P_NO" PRIMARY KEY ("P_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "PK_PB_NO" PRIMARY KEY ("PB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" MODIFY ("PBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "PK_PBC_NO" PRIMARY KEY ("PBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_LOVE_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "PK_PBL_LOVE_NO" PRIMARY KEY ("PBL_LOVE_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_X" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_Y" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "PK_PP_NO" PRIMARY KEY ("PP_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" MODIFY ("RB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "PK_RB_NO" PRIMARY KEY ("RB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_RBA_NO" PRIMARY KEY ("RBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" MODIFY ("RBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "PK_RBC_NO" PRIMARY KEY ("RBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_LOVE_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "PK_RBL_LOVE_NO" PRIMARY KEY ("RBL_LOVE_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "FK_CHAT_CONTENT" FOREIGN KEY ("CC_CR_ID", "CC_M_EMAIL")
	  REFERENCES "TMI_CHAT_ROOM" ("CR_ID", "CR_M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_M_EMAIL" FOREIGN KEY ("CR_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_P_NO" FOREIGN KEY ("FB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_M_EMAIL" FOREIGN KEY ("FB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_FB_NO" FOREIGN KEY ("FBA_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_COMENT_RB_NO" FOREIGN KEY ("FBC_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_M_EMAIL" FOREIGN KEY ("FBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "FK_MEMBER_ROLE_M_EMAIL" FOREIGN KEY ("MR_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "FK_NOTICE_BOARD_M_EMAIL" FOREIGN KEY ("NB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_NB_NO" FOREIGN KEY ("NBA_NB_NO")
	  REFERENCES "TMI_NOTICE_BOARD" ("NB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "FK_PLANNER_M_EMAIL" FOREIGN KEY ("P_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_P_NO" FOREIGN KEY ("PB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_M_EMAIL" FOREIGN KEY ("PB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_PB_NO" FOREIGN KEY ("PBC_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_M_EMAIL" FOREIGN KEY ("PBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_PB_NO" FOREIGN KEY ("PBL_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("PBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "FK_PLANNER_PLAN_P_NO" FOREIGN KEY ("PP_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_P_NO" FOREIGN KEY ("RB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_M_EMAIL" FOREIGN KEY ("RB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_REVIEW_BOARD_ATTACHMENT_RB_NO" FOREIGN KEY ("RBA_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_COMENT_RB_NO" FOREIGN KEY ("RBC_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_M_EMAIL" FOREIGN KEY ("RBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_RB_NO" FOREIGN KEY ("RBL_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("RBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
