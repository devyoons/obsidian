--------------------------------------------------------
--  파일이 생성됨 - 화요일-8월-09-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PERSISTENT_LOGINS
--------------------------------------------------------

  CREATE TABLE "PERSISTENT_LOGINS" 
   (	"USERNAME" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"SERIES" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"TOKEN" VARCHAR2(64) COLLATE "USING_NLS_COMP", 
	"LAST_USED" TIMESTAMP (6)
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_CONTENT" 
   (	"CC_NO" NUMBER, 
	"CC_CR_TITLE" VARCHAR2(50) COLLATE "USING_NLS_COMP", 
	"CC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"CC_MESSAGE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"CC_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_CHAT_ROOM
--------------------------------------------------------

  CREATE TABLE "TMI_CHAT_ROOM" 
   (	"CR_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"CR_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"CR_FB_NO" NUMBER, 
	"CR_CREATED_AT" DATE DEFAULT sysdate, 
	"CR_LAST_CHECK" NUMBER, 
	"CR_DELETED_AT" DATE
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD" 
   (	"FB_NO" NUMBER, 
	"FB_P_NO" NUMBER, 
	"FB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_TITLE" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FB_CREATED_AT" DATE DEFAULT sysdate, 
	"FB_UPDATED_AT" DATE DEFAULT sysdate, 
	"FB_READ_COUNT" NUMBER DEFAULT 0, 
	"FB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_ATTACHMENT" 
   (	"FBA_NO" NUMBER, 
	"FBA_FB_NO" NUMBER, 
	"FBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"TBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_FRIEND_BOARD_COMMENT" 
   (	"FBC_NO" NUMBER, 
	"FBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"FBC_FB_NO" NUMBER, 
	"FBC_CREATED_AT" DATE DEFAULT sysdate, 
	"FBC_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER" 
   (	"M_NO" NUMBER, 
	"M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_NICKNAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PASSWORD" VARCHAR2(512) COLLATE "USING_NLS_COMP", 
	"M_NAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_PHONE" CHAR(11) COLLATE "USING_NLS_COMP", 
	"M_SOCIALTYPE" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"M_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  CREATE TABLE "TMI_MEMBER_ROLE" 
   (	"MR_AUTH" VARCHAR2(20) COLLATE "USING_NLS_COMP", 
	"MR_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD" 
   (	"NB_NO" NUMBER, 
	"NB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"NB_CREATED_AT" DATE DEFAULT sysdate, 
	"NB_UPDATE_AT" DATE DEFAULT sysdate, 
	"NB_READ_COUNT" NUMBER DEFAULT 0, 
	"NB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_NOTICE_BOARD_ATTACHMENT" 
   (	"NBA_NO" NUMBER, 
	"NBA_NB_NO" NUMBER, 
	"NBA_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"NBA_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER" 
   (	"P_NO" NUMBER, 
	"P_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"P_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_EXPLAN" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"P_LEAVE_DATE" DATE, 
	"P_RETURN_DATE" DATE, 
	"P_WRITE_DATE" DATE DEFAULT sysdate, 
	"P_SHARE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT 'N'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD" 
   (	"PB_NO" NUMBER, 
	"PB_P_NO" NUMBER, 
	"PB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PB_CREATED_AT" DATE DEFAULT sysdate, 
	"PB_UPDATED_AT" DATE DEFAULT sysdate, 
	"PB_READ_COUNT" NUMBER DEFAULT 0, 
	"PB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_COMMENT" 
   (	"PBC_NO" NUMBER, 
	"PBC_PB_NO" NUMBER, 
	"PBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBC_CREATED_AT" DATE DEFAULT sysdate, 
	"PBC_CONTENT" VARCHAR2(256) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_BOARD_LOVE" 
   (	"PBL_LOVE_NO" NUMBER, 
	"PBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"PBL_PB_NO" NUMBER, 
	"PBL_LOVETYPE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT '0'
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  CREATE TABLE "TMI_PLANNER_PLAN" 
   (	"PP_NO" NUMBER, 
	"PP_P_NO" NUMBER, 
	"PP_DATE" DATE DEFAULT sysdate, 
	"PP_PLACE_NAME" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PP_MEMO" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"PP_X" NUMBER, 
	"PP_Y" NUMBER
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD" 
   (	"RB_NO" NUMBER, 
	"RB_P_NO" NUMBER, 
	"RB_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_TITLE" VARCHAR2(2000) COLLATE "USING_NLS_COMP", 
	"RB_CREATED_AT" DATE DEFAULT sysdate, 
	"RB_UPDATED_AT" DATE DEFAULT sysdate, 
	"RB_READ_COUNT" NUMBER DEFAULT 0, 
	"RB_CONTENT" CLOB COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_ATTACHMENT" 
   (	"RBA_NO" NUMBER, 
	"RBA_RB_NO" NUMBER, 
	"RBA_ATTACHMENT_ORIGINAL_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_ATTACHMENT_RENAMED_FILENAME" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBA_ATTACHMENT_CREATED_AT" DATE DEFAULT sysdate
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_COMMENT" 
   (	"RBC_NO" NUMBER, 
	"RBC_RB_NO" NUMBER, 
	"RBC_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RB_COMMENT_CREATE_AT" DATE DEFAULT sysdate, 
	"RB_CONTENT" VARCHAR2(1000) COLLATE "USING_NLS_COMP"
   )  DEFAULT COLLATION "USING_NLS_COMP"
--------------------------------------------------------
--  DDL for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  CREATE TABLE "TMI_REVIEW_BOARD_LOVE" 
   (	"RBL_LOVE_NO" NUMBER, 
	"RBL_RB_NO" NUMBER, 
	"RBL_M_EMAIL" VARCHAR2(256) COLLATE "USING_NLS_COMP", 
	"RBL_LOVETYPE" CHAR(1) COLLATE "USING_NLS_COMP" DEFAULT 0
   )  DEFAULT COLLATION "USING_NLS_COMP"
REM INSERTING into PERSISTENT_LOGINS
SET DEFINE OFF;
Insert into PERSISTENT_LOGINS (USERNAME,SERIES,TOKEN,LAST_USED) values ('TMI@gmail.com','g1DmNU4SHQBvqLEvgekGjQ==','w34LkXdHRnRy9+Cpmetc0w==',to_timestamp('22/08/08 20:44:29.290000000','RR/MM/DD HH24:MI:SSXFF'));
Insert into PERSISTENT_LOGINS (USERNAME,SERIES,TOKEN,LAST_USED) values ('honggd@naver.com','8/UtY6id99G5v4Jor1nkAQ==','SLBd4jplK0JrQDI+HTid9w==',to_timestamp('22/08/08 00:42:02.366000000','RR/MM/DD HH24:MI:SSXFF'));
REM INSERTING into TMI_CHAT_CONTENT
SET DEFINE OFF;
REM INSERTING into TMI_CHAT_ROOM
SET DEFINE OFF;
REM INSERTING into TMI_FRIEND_BOARD
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (82,null,'honggd@naver.com','asd',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (83,null,'honggd@naver.com','asd12',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (84,null,'honggd@naver.com','첨부파일 확인',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (85,null,'honggd@naver.com','첨부파일 확인 ',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (86,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (21,null,'ks1234@naver.com','테스트',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (22,null,'ks1234@naver.com','테스트7',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (23,null,'ks1234@naver.com','테스트8',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (24,null,'ks1234@naver.com','테스트9',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (25,null,'ks1234@naver.com','테스트10',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (26,null,'ks1234@naver.com','테스트11',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (27,null,'ks1234@naver.com','테스트12',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (28,null,'ks1234@naver.com','테스트13',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (29,null,'ks1234@naver.com','테스트14',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (30,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (31,null,'ym1234@naver.com','테스트2',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (32,null,'ys1234@naver.com','테스트3',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (33,null,'mj1234@naver.com','테스트4',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (34,null,'ic1234@naver.com','테스트5',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (35,null,'th1234@naver.com','테스트6',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (36,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (37,null,'ks1234@naver.com','테스트15',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (38,null,'ks1234@naver.com','테스트16',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (39,null,'ks1234@naver.com','테스트17',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (40,null,'ks1234@naver.com','테스트18',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (41,null,'ks1234@naver.com','테스트19',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (42,null,'ks1234@naver.com','테스트20',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (43,null,'ks1234@naver.com','테스트21',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (44,null,'ks1234@naver.com','테스트22',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (45,null,'ks1234@naver.com','테스트23',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (46,null,'ks1234@naver.com','테스트24',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (47,null,'ks1234@naver.com','테스트25',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (48,null,'ks1234@naver.com','테스트26',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (49,null,'ks1234@naver.com','테스트27',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (50,null,'ks1234@naver.com','테스트28',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (51,null,'ks1234@naver.com','테스트29',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (52,null,'ks1234@naver.com','테스트30',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (53,null,'ks1234@naver.com','테스트31',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (54,null,'ks1234@naver.com','테스트32',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (55,null,'ks1234@naver.com','테스트33',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (56,null,'ks1234@naver.com','테스트34',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (57,null,'ks1234@naver.com','테스트35',to_date('22/08/03','RR/MM/DD'),to_date('22/08/04','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (67,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (68,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (69,null,'ks1234@naver.com',null,to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (70,null,'ks1234@naver.com','가나다',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (71,null,'ks1234@naver.com','가나다asd',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (72,null,'ks1234@naver.com','가나다asdww',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (73,null,'honggd@naver.com','asdwww',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (87,null,'honggd@naver.com','aasd',to_date('22/08/08','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (65,null,'ks1234@naver.com','테스트',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (66,null,'ks1234@naver.com','테스트22222',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (74,null,'honggd@naver.com','되라',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (75,null,'honggd@naver.com','ㅁㄴㅇ',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (76,null,'honggd@naver.com','이미지가 억까한다',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (77,null,'honggd@naver.com','asd',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (78,null,'honggd@naver.com','이미지 몇개',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (79,null,'honggd@naver.com','이미지 테스트',to_date('22/08/06','RR/MM/DD'),to_date('22/08/06','RR/MM/DD'),0);
Insert into TMI_FRIEND_BOARD (FB_NO,FB_P_NO,FB_M_EMAIL,FB_TITLE,FB_CREATED_AT,FB_UPDATED_AT,FB_READ_COUNT) values (81,null,'honggd@naver.com','첨부파일 실험',to_date('22/08/07','RR/MM/DD'),to_date('22/08/07','RR/MM/DD'),0);
REM INSERTING into TMI_FRIEND_BOARD_ATTACHMENT
SET DEFINE OFF;
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (41,83,'fish.png','20220808_014937607_291.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (42,84,'dog.png','20220808_015012885_272.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (43,86,'dog.png','20220808_015956206_217.png',to_date('22/08/07','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (22,21,'test.jpg','20200525_090909_123.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (23,22,'moon.jpg','20200525_090909_345.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (24,23,'sun.jpg','20200525_020425_345.jpg',to_date('22/08/05','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (44,87,'cat.png','20220808_150146453_216.png',to_date('22/08/08','RR/MM/DD'));
Insert into TMI_FRIEND_BOARD_ATTACHMENT (FBA_NO,FBA_FB_NO,FBA_ORIGINAL_FILENAME,FBA_RENAMED_FILENAME,TBA_CREATED_AT) values (45,87,'dog.png','20220808_150146454_855.png',to_date('22/08/08','RR/MM/DD'));
REM INSERTING into TMI_FRIEND_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_MEMBER
SET DEFINE OFF;
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (103,'ddp3381@naver.com','싱코페이션','$2a$10$EyZJFtlw83ak12CMzTR0h.awMe21lq00rCp9N5VX3reJ4RVAtFXZS','안태현','01076563381',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (145,'danji@naver.com','뚱단지','$2a$10$gJ8gy68uQ8OkgfbamaMbFuvIZBFQK/gJ8R0ySzPWq5P0G2CpkgyQW','최단지','01012341234',null,to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (101,'ggy3381@naver.com','이방인','$2a$10$1AMYvftCUfP6UQVfikhVtODvHanH0sH9Rk.cPQ4mETFCLXsfyvtxS','안태현','01076563381',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (148,'bsj1234@naver.com','박서준','$2a$10$He30zB0YvtY8NdX7kZHnLuZcG2556zso3rF2J3T5mrh0eyzWyblVu','박서준','01012341234',null,to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (71,'admin@naver.com','관리자','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','관리자','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (72,'ym1234@naver.com','김용민','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','ym1234','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (73,'ks1234@naver.com','이경석','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','ks1234','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (74,'ys1234@naver.com','최윤서','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','ys1234','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (75,'mj1234@naver.com','권민지','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','mj1234','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (76,'ic1234@naver.com','전인찬','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','ic1234','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (77,'th1234@naver.com','안태현','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','th1234','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (78,'test1111@naver.com','테스트1','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','test1111','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (79,'test2222@naver.com','테스트2','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','test2222','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (80,'test3333@naver.com','테스트3','$2a$10$oDUuqgA16JOHn39iSwq.GeIYzPvj5MyjlA01buPbC6K.ikxFobXGi','test3333','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (125,'TMI@gmail.com','이아엠티','$2a$10$NqyEATUKYfhm1Ny3Xe9QbOx3rwPE0vRsrjHbaGdLAr3UlP9EwELQa','티엠아이','01012349876',null,to_date('22/08/06','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (146,'dmin@naver.com','드드민','$2a$10$S0hwPdWyzhB13VmiXFynuugR5RMcvHfPt.S5NxMd7UfDWN9P2Zxom','이드민','01011112233',null,to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (81,'honggd@naver.com','홍홍홍','$2a$10$EXTuRLRjK1z5DxbngxRhcOv74jtWGcspNLssI0sOvj2gGLs8a/OEO','홍길동','01000000000',null,to_date('22/08/05','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (144,'munji@naver.com','냥펀치','$2a$10$FfpQpLtCgNR76oj4IF/MteY6NujD7u.Av/HGzDjoIqkvrbVEYIuQu','최먼지','01023234343',null,to_date('22/08/07','RR/MM/DD'));
Insert into TMI_MEMBER (M_NO,M_EMAIL,M_NICKNAME,M_PASSWORD,M_NAME,M_PHONE,M_SOCIALTYPE,M_CREATED_AT) values (147,'tan1234@naver.com','탄왕자','$2a$10$7YBrrMRAEZFDsreQpMLyje1lAqkgkrQrYoKesS1PVz./N7a0oE/cq','최탄','01012341234',null,to_date('22/08/07','RR/MM/DD'));
REM INSERTING into TMI_MEMBER_ROLE
SET DEFINE OFF;
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_ADMIN','admin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','TMI@gmail.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','bsj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','danji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ddp3381@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','dmin@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ggy3381@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','honggd@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ic1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ks1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','mj1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','munji@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','tan1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','test1111@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','test2222@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','test3333@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','th1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ym1234@naver.com');
Insert into TMI_MEMBER_ROLE (MR_AUTH,MR_M_EMAIL) values ('ROLE_USER','ys1234@naver.com');
REM INSERTING into TMI_NOTICE_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_NOTICE_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER
SET DEFINE OFF;
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE,P_SHARE) values (85,'ym1234@naver.com','test','z',to_date('22/08/01','RR/MM/DD'),to_date('22/08/03','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),'N');
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE,P_SHARE) values (86,'ym1234@naver.com','test2','1',to_date('22/08/04','RR/MM/DD'),to_date('22/08/10','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),'N');
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE,P_SHARE) values (87,'ym1234@naver.com','zz','asd',to_date('22/08/02','RR/MM/DD'),to_date('22/08/17','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),'N');
Insert into TMI_PLANNER (P_NO,P_M_EMAIL,P_TITLE,P_EXPLAN,P_LEAVE_DATE,P_RETURN_DATE,P_WRITE_DATE,P_SHARE) values (88,'ks1234@naver.com','tyest','123',to_date('22/08/03','RR/MM/DD'),to_date('22/08/17','RR/MM/DD'),to_date('22/08/08','RR/MM/DD'),'N');
REM INSERTING into TMI_PLANNER_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_BOARD_LOVE
SET DEFINE OFF;
REM INSERTING into TMI_PLANNER_PLAN
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD_ATTACHMENT
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD_COMMENT
SET DEFINE OFF;
REM INSERTING into TMI_REVIEW_BOARD_LOVE
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C0042194
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0042194" ON "PERSISTENT_LOGINS" ("SERIES")
--------------------------------------------------------
--  DDL for Index PK_CC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CC_NO" ON "TMI_CHAT_CONTENT" ("CC_NO")
--------------------------------------------------------
--  DDL for Index PK_CHAT_MEMBER
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CHAT_MEMBER" ON "TMI_CHAT_ROOM" ("CR_TITLE", "CR_M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_FB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FB_NO" ON "TMI_FRIEND_BOARD" ("FB_NO")
--------------------------------------------------------
--  DDL for Index PK_FBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBA_NO" ON "TMI_FRIEND_BOARD_ATTACHMENT" ("FBA_NO")
--------------------------------------------------------
--  DDL for Index PK_FBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_FBC_NO" ON "TMI_FRIEND_BOARD_COMMENT" ("FBC_NO")
--------------------------------------------------------
--  DDL for Index PK_M_EMAIL
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_M_EMAIL" ON "TMI_MEMBER" ("M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_MR_AUTH
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MR_AUTH" ON "TMI_MEMBER_ROLE" ("MR_AUTH", "MR_M_EMAIL")
--------------------------------------------------------
--  DDL for Index PK_NB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NB_NO" ON "TMI_NOTICE_BOARD" ("NB_NO")
--------------------------------------------------------
--  DDL for Index PK_NBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_NBA_NO" ON "TMI_NOTICE_BOARD_ATTACHMENT" ("NBA_NO")
--------------------------------------------------------
--  DDL for Index PK_P_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_P_NO" ON "TMI_PLANNER" ("P_NO")
--------------------------------------------------------
--  DDL for Index PK_PB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PB_NO" ON "TMI_PLANNER_BOARD" ("PB_NO")
--------------------------------------------------------
--  DDL for Index PK_PBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBC_NO" ON "TMI_PLANNER_BOARD_COMMENT" ("PBC_NO")
--------------------------------------------------------
--  DDL for Index PK_PBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PBL_LOVE_NO" ON "TMI_PLANNER_BOARD_LOVE" ("PBL_LOVE_NO")
--------------------------------------------------------
--  DDL for Index PK_PP_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PP_NO" ON "TMI_PLANNER_PLAN" ("PP_NO")
--------------------------------------------------------
--  DDL for Index PK_RB_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RB_NO" ON "TMI_REVIEW_BOARD" ("RB_NO")
--------------------------------------------------------
--  DDL for Index PK_RBA_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBA_NO" ON "TMI_REVIEW_BOARD_ATTACHMENT" ("RBA_NO")
--------------------------------------------------------
--  DDL for Index PK_RBC_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBC_NO" ON "TMI_REVIEW_BOARD_COMMENT" ("RBC_NO")
--------------------------------------------------------
--  DDL for Index PK_RBL_LOVE_NO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_RBL_LOVE_NO" ON "TMI_REVIEW_BOARD_LOVE" ("RBL_LOVE_NO")
--------------------------------------------------------
--  Constraints for Table PERSISTENT_LOGINS
--------------------------------------------------------

  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("USERNAME" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("TOKEN" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" MODIFY ("LAST_USED" NOT NULL ENABLE)
  ALTER TABLE "PERSISTENT_LOGINS" ADD PRIMARY KEY ("SERIES")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" MODIFY ("CC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "PK_CC_NO" PRIMARY KEY ("CC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CR_TITLE" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" MODIFY ("CR_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "PK_CHAT_MEMBER" PRIMARY KEY ("CR_TITLE", "CR_M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" MODIFY ("FB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "PK_FB_NO" PRIMARY KEY ("FB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" MODIFY ("FBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_FBA_NO" PRIMARY KEY ("FBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" MODIFY ("FBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "PK_FBC_NO" PRIMARY KEY ("FBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NICKNAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PASSWORD" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_NAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" MODIFY ("M_PHONE" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER" ADD CONSTRAINT "PK_M_EMAIL" PRIMARY KEY ("M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" MODIFY ("MR_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "PK_MR_AUTH" PRIMARY KEY ("MR_AUTH", "MR_M_EMAIL")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" MODIFY ("NB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "PK_NB_NO" PRIMARY KEY ("NB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" MODIFY ("NBA_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_NBA_NO" PRIMARY KEY ("NBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" MODIFY ("P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_TITLE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_LEAVE_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" MODIFY ("P_RETURN_DATE" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "PK_P_NO" PRIMARY KEY ("P_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" MODIFY ("PB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "PK_PB_NO" PRIMARY KEY ("PB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" MODIFY ("PBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "PK_PBC_NO" PRIMARY KEY ("PBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_LOVE_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" MODIFY ("PBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "PK_PBL_LOVE_NO" PRIMARY KEY ("PBL_LOVE_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_P_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_X" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" MODIFY ("PP_Y" NOT NULL ENABLE)
  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "PK_PP_NO" PRIMARY KEY ("PP_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" MODIFY ("RB_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "PK_RB_NO" PRIMARY KEY ("RB_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_ATTACHMENT_ORIGINAL_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" MODIFY ("RBA_ATTACHMENT_RENAMED_FILENAME" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "PK_RBA_NO" PRIMARY KEY ("RBA_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" MODIFY ("RBC_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "PK_RBC_NO" PRIMARY KEY ("RBC_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_LOVE_NO" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" MODIFY ("RBL_M_EMAIL" NOT NULL ENABLE)
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "PK_RBL_LOVE_NO" PRIMARY KEY ("RBL_LOVE_NO")
  USING INDEX  ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_CONTENT
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_CONTENT" ADD CONSTRAINT "FK_CHAT_CONTENT" FOREIGN KEY ("CC_CR_TITLE", "CC_M_EMAIL")
	  REFERENCES "TMI_CHAT_ROOM" ("CR_TITLE", "CR_M_EMAIL") ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_CHAT_ROOM
--------------------------------------------------------

  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_M_EMAIL" FOREIGN KEY ("CR_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_CHAT_ROOM" ADD CONSTRAINT "FK_CHAT_ROOM_FB_NO" FOREIGN KEY ("CR_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_P_NO" FOREIGN KEY ("FB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD" ADD CONSTRAINT "FK_FRIEND_BOARD_M_EMAIL" FOREIGN KEY ("FB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_FB_NO" FOREIGN KEY ("FBA_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_FRIEND_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_COMENT_RB_NO" FOREIGN KEY ("FBC_FB_NO")
	  REFERENCES "TMI_FRIEND_BOARD" ("FB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_FRIEND_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_FRIEND_M_EMAIL" FOREIGN KEY ("FBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_MEMBER_ROLE
--------------------------------------------------------

  ALTER TABLE "TMI_MEMBER_ROLE" ADD CONSTRAINT "FK_MEMBER_ROLE_M_EMAIL" FOREIGN KEY ("MR_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD" ADD CONSTRAINT "FK_NOTICE_BOARD_M_EMAIL" FOREIGN KEY ("NB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_NOTICE_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_NOTICE_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_FRIEND_BOARD_ATTACHMENT_NB_NO" FOREIGN KEY ("NBA_NB_NO")
	  REFERENCES "TMI_NOTICE_BOARD" ("NB_NO") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER" ADD CONSTRAINT "FK_PLANNER_M_EMAIL" FOREIGN KEY ("P_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_P_NO" FOREIGN KEY ("PB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD" ADD CONSTRAINT "FK_PLANNER_BOARD_M_EMAIL" FOREIGN KEY ("PB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_PB_NO" FOREIGN KEY ("PBC_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_BOARD_COMMENT_M_EMAIL" FOREIGN KEY ("PBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_PB_NO" FOREIGN KEY ("PBL_PB_NO")
	  REFERENCES "TMI_PLANNER_BOARD" ("PB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_PLANNER_BOARD_LOVE" ADD CONSTRAINT "FK_PLANNER_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("PBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_PLANNER_PLAN
--------------------------------------------------------

  ALTER TABLE "TMI_PLANNER_PLAN" ADD CONSTRAINT "FK_PLANNER_PLAN_P_NO" FOREIGN KEY ("PP_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_P_NO" FOREIGN KEY ("RB_P_NO")
	  REFERENCES "TMI_PLANNER" ("P_NO") ON DELETE SET NULL ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD" ADD CONSTRAINT "FK_REVIEW_BOARD_M_EMAIL" FOREIGN KEY ("RB_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_ATTACHMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_ATTACHMENT" ADD CONSTRAINT "FK_REVIEW_BOARD_ATTACHMENT_RB_NO" FOREIGN KEY ("RBA_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_COMMENT
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_COMENT_RB_NO" FOREIGN KEY ("RBC_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_COMMENT" ADD CONSTRAINT "FK_PLANNER_REVIEW_M_EMAIL" FOREIGN KEY ("RBC_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE SET NULL ENABLE
--------------------------------------------------------
--  Ref Constraints for Table TMI_REVIEW_BOARD_LOVE
--------------------------------------------------------

  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_RB_NO" FOREIGN KEY ("RBL_RB_NO")
	  REFERENCES "TMI_REVIEW_BOARD" ("RB_NO") ON DELETE CASCADE ENABLE
  ALTER TABLE "TMI_REVIEW_BOARD_LOVE" ADD CONSTRAINT "FK_REVIEW_BOARD_LOVE_M_EMAIL" FOREIGN KEY ("RBL_M_EMAIL")
	  REFERENCES "TMI_MEMBER" ("M_EMAIL") ON DELETE CASCADE ENABLE
